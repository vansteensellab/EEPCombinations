
#' @title datteRo: an R package for the analysis of DAT (Deconstruct A TAD) experiments.
#'
#' @description datteRo: an R package for the analysis of DAT (Deconstruct A TAD) experiments. Currently intended for internal use.
#' The name means 'date' (the fruit) in Italian, and could perhaps be understood as ‘Deconstruct A TAD and Then Extract Relevant Observations’
#'
#' @author Federico Comoglio
#'
#' @docType package
#' @name datteRo-package
#' @aliases datteRo-package
#' @keywords package
#'
#' @import tidyverse
#' @import magrittr
#' @import GenomicRanges
#' @import IRanges
#' @importFrom mclust Mclust
#' @importFrom mclust mclustBIC
#' @importFrom GGally ggpairs
#' @importFrom GGally ggally_text
#' @importFrom cowplot ggdraw
#' @importFrom cowplot draw_plot
#' @importFrom egg ggarrange
#' @importFrom ggbeeswarm geom_beeswarm
#' @importFrom wesanderson wes_palette
#' @importFrom ggpubr stat_cor
#' @importFrom bamsignals bamCount
#'
NULL

