#' @title Combine barcode expression and copy number counts for each replicate/condition
#'
#' @usage merge_ipcr_ecn(tib, cn_tib_list, expr_tib_list)
#'
#' @param tib tibble, containing basal or combinatorial library fragments (imported with \link{read_ipcr})
#' @param cn_tib_list list of tibbles with copy number counts (imported with \link{read_ecn}), where each element corresponds to one biological replicate or condition of interest
#' @param expr_tib_list list of tibbles with barcode expression counts (imported with \link{read_ecn}), where each element corresponds to one biological replicate or condition of interest
#'
#' @return A tibble with barcode expression and copy number counts for all ipcr barcodes with copy number > 0, for each replicate/condition
#'
#' @note NA counts are replaced with 0
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export merge_ipcr_ecn
#'
#'
merge_ipcr_ecn <- function(tib, cn_tib_list, expr_tib_list) {

  # add tib to cn tibbles
  l_cn <- c(list(tib), cn_tib_list)

  # merge, retaining all ipcr barcodes with copy number > 0
  tmp  <- purrr::reduce(l_cn, inner_join, by = 'barcode')

  # add result to expr tibbles
  l_expr <- c(list(tmp), expr_tib_list)

  # merge --> replace NA with 0L
  tib_merged <- purrr::reduce(l_expr, left_join, by = 'barcode')
  tib_merged[is.na(tib_merged)] <- 0L

  tib_merged
}


#' @title Summarize pDNA counts for each barcode across replicates
#'
#' @usage combine_cn(tib)
#'
#' @param tib tibble, containing merged basal or combinatorial library fragments (see \link{merge_ipcr_ecn})
#'
#' @return a tibble
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export combine_cn
#'
#'
combine_cn <- function(tib) {

  # detect number of replicates based on colnames (diagnostic)
  n_repl <- dplyr::select(tib, starts_with('pdna_counts_')) %>%
    ncol

  message('Detected ', n_repl, ' replicates')

  # summarize pDNA counts across replicates
  tib %>%
    mutate(pdna_counts = rowSums(dplyr::select(., starts_with('pdna_counts_')))) %>%
    dplyr::select(-starts_with('pdna_counts_')) %>%
    dplyr::select(barcode:id, pdna_counts, starts_with('cdna_counts_'))

}


#' @title Remove barcodes with insufficient pDNA counts
#'
#' @usage filter_cn(tib, min_pdna)
#'
#' @param tib  tibble, containing merged and summarized basal or combinatorial library fragments (see \link{merge_ipcr_ecn} and \link{combine_cn})
#' @param min_pdna integer, the pDNA count threshold to be used for filtering
#'
#' @return a tibble
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export filter_cn
#'
#'
# filter out barcodes with low copy number
filter_cn <- function(tib, min_pdna) {

  # check whether replicates were summarized
  n <- tib %>%
    dplyr::select(matches('pdna_counts')) %>%
    ncol

  if(n !=1)
    stop('pDNA counts for replicates need to be summarized before filtering; see combine_cn')

  tib %>%
    dplyr::filter(pdna_counts >= min_pdna)
}


#' @title Remove fragments with insufficient barcode diversity (+diagnostic plot)
#'
#' @usage filter_barcodes(tib, min_n_bc, main = '')
#'
#' @param tib tibble, containing merged and summarized basal or combinatorial library fragments (see \link{merge_ipcr_ecn} and \link{combine_cn})
#' @param min_n_bc integer, minimum number of different barcodes to be used for filtering
#' @param main character, the ECDF plot title
#'
#' @return a tibble. In addition, the function returns an ECDF plot of barcode diversity
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export filter_barcodes
#'
#'
filter_barcodes <- function(tib, min_n_bc, main = '') {

  # validate args
  if(missing(min_n_bc))
    stop('Please specify the minimum required number of barcodes (see argument min_n_bc)')

  # group barcodes by id -> add # distinct barcodes
  tib_grouped <- tib %>%
    group_by(id) %>%
    summarize(n_bc = n_distinct(barcode))

  p <- tib_grouped %>%
    ggplot(aes(n_bc)) +
    stat_ecdf() +
    labs(x = 'Distinct barcodes', y = 'Fraction of library', title = main) +
    geom_vline(xintercept = min_n_bc, color = 'skyblue3') +
    theme_bw()

  print(p)

  tib %>%
    inner_join(tib_grouped, by = 'id') %>%
    filter(n_bc >= min_n_bc)
}


#' @title Normalized expression and copy number counts by library sizes
#'
#' @usage normalize_counts(tib, offsets)
#'
#' @param tib tibble, containing merged, summarized and filtered basal or combinatorial library fragments (see \link{merge_ipcr_ecn}, \link{combine_cn}, \link{filter_cn} and \link{filter_barcodes})
#' @param offsets integer named vector, containg the total number of reads in each library. The vector names must match the names of the samples/conditions in the input tibble
#'
#' @return a tibble
#'
#' @note None
#'
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export normalize_counts
#'
#'
# normalize to library sizes
# tib: input tibble (basal/comb)
# offsets: named vector with mio. reads (lib sizes). The length should match the number of samples to be normalized, the order of the samples is checked internally.
normalize_counts <- function(tib, offsets) {

  tib_counts <- tib %>%
    dplyr::select(contains('dna_counts'))
  tib <- tib %>%
    dplyr::select(-contains('dna_counts'))

  # check that order of samples is the same bw inputs and stopifnot
  nm_counts <- names(tib_counts) %>%
    str_replace('_counts', '')

  if(any(nm_counts != names(offsets))) {
    message('Order of counts: ', names(tib_counts))
    message('Order of offsets: ', names(offsets))

    stop('Order of samples in input different from order of offsets')
  }

  # normalize counts to offsets
  # note: elementwise matrix div; t() implicitly coerce to matrix
  tib_counts <- t(t(tib_counts) / offsets) %>%
    as_data_frame()

  tib <- bind_cols(tib, tib_counts)
  tib
}


#' @title Compute activities (normalized cDNA/pDNA ratio)
#'
#' @usage compute_activities(tib)
#'
#' @param tibble, containing merged, summarized, filtered and offset-normalized basal or combinatorial library fragments (see \link{merge_ipcr_ecn}, \link{combine_cn}, \link{filter_cn}, \link{filter_barcodes} and \link{normalize_counts})
#'
#' @return a tibble
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export compute_activities
#'
#'
compute_activities <- function(tib) {

  tib_counts <- tib %>%
    dplyr::select(contains('dna_counts'))

  # normalize cDNA counts to pDNA
  denom <- tib_counts[['pdna_counts']]
  tib_counts <- (tib_counts / denom) %>%
    as_data_frame() %>%
    dplyr::select(-pdna_counts)

  # rename cols
  names(tib_counts) <- str_replace(names(tib_counts), 'cdna_counts', 'activity')

  tib <- bind_cols(tib, tib_counts)
  tib
}


#' @title Summarize fragment activity (weighted average over barcodes)
#'
#' @usage summarize_barcodes(tib, type = 'wa')
#'
#' @param tib tibble, containing merged, summarized, filtered and offset-normalized basal or combinatorial library fragments containing barcode-level activity values (see \link{compute_activities})
#' @param type character, if 'wa' barcode-level activities are summarized using a weighted average (weights proportional to normalized pDNA counts). If 'avg' barcodes are summarized using an arithmetic average
#'
#' @return a tibble
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export summarize_barcodes
#'
#'
summarize_barcodes <- function(tib, type = 'wa') {

  # stop if type not 'wa'/'avg'
  if(!type %in% c('wa', 'avg'))
    stop('type should be equal to wa for a weighted average, or to avg for an arithmetic average')

  # aux function that works on a nested tibble ($data slot)
  get_summarized_vals <- function(dat, type) {

    # extract pDNA counts
    pdna_counts <- dat[['pdna_counts']]
    denom       <- sum(pdna_counts)

    # extract activity values
    dat <- dat %>%
      dplyr::select(starts_with('activity_'))

    if(type == 'wa') {

      # summarize barcode activities using a weighted average (w = pdna counts)
      vec_summarized <- colSums(dat * pdna_counts) / denom

    }

    else {

      # summarize barcode activities using an arithmetic average
      vec_summarized <- colMeans(dat)

    }

    # take geom mean of activities
    vec_summarized[['activity_all']] <- prod(vec_summarized) ^ (1 / length(vec_summarized))

    return(vec_summarized)
  }

  # nest input tibble by element identity
  tib_nested <- tib %>%
    group_by(id, frag1, strand1, frag2, strand2) %>%
    nest()

  tib_summarized <- purrr::map(tib_nested$data, get_summarized_vals, type = type) %>%
    do.call(what = 'rbind') %>%
    as_data_frame()

  tib_nested %>%
    # drop data slot = unnest
    dplyr::select(-data) %>%
    bind_cols(tib_summarized)
}



#' @title Fit a Gaussian mixture model to classify active and inactive pairs
#'
#' @usage fit_gmm(x, n.comp = 2, var.equal = FALSE, ...)
#'
#' @param x numeric, the input vector
#' @param n.comp numeric, the number of components
#' @param var.equal logical, if TRUE, components have the same variance
#' @param ... additional parameters to be passed to the `mclust` function
#'
#' @return an `mclust` model object
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export fit_gmm
#'
#'
fit_gmm <- function(x, n.comp = 2, var.equal = FALSE, ...) {
  stopifnot(is.numeric(x))

  this.model <- ifelse(var.equal, 'E', 'V')
  model <- mclust::Mclust(x, G = n.comp, modelNames = this.model, ...)

  return(model)
}


#' @title Fit a Gaussian mixture model to classify active and inactive pairs, and compute the activity threshold
#'
#' @usage learn_min_activity(tib)
#'
#' @param tib tibble, containing merged, summarized, filtered and offset-normalized basal or combinatorial library fragments containing summarized activity values (see \link{summarize_barcodes})
#'
#' @return an activity threshold (numeric)
#'
#' @note Currently, the geometric mean of activities across replicates (denoted as `activity_all`) is used to learn the activity threshold
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export learn_min_activity
#'
#'
learn_min_activity <- function(tib) {
  set.seed(100)

  # extract log2 activities
  x   <- tib[['activity_all']] %>%
    log2

  x   <- x[-which(x == -Inf)]
  fit <- fit_gmm(x, n.comp = 2, var.equal = FALSE)

  # class labels -> list
  l <- list(noise  = x[fit$classification == 1],
            signal = x[fit$classification == 2])

  # compute signal threshold
  threshold <- max(l[['noise']])

  # plot diagnostics
  plot_gmm(x, fit)

  p <- melt(l) %>%
    ggplot(aes(x = L1, y = value)) +
    geom_boxplot(outlier.shape = NA) +
    labs(x = '', y = 'log2(combinatorial activity)') +
    geom_hline(yintercept = threshold) +
    theme_bw()
  #  print(p)

  return(2 ^ threshold)
}


#' @title Compute cooperativity indices
#'
#' @usage compute_cooperativity(tib_comb, tib_basal, signal_t, remove_inactive = TRUE)
#'
#' @param tib_comb tibble, containing merged, summarized, filtered and offset-normalized combinatorial library fragments containing summarized activity values (see \link{summarize_barcodes})
#' @param tib_basal tibble, containing merged, summarized, filtered and offset-normalized basal library fragments containing summarized activity values (see \link{summarize_barcodes})
#' @param signal_t numeric, the activity threshold (see \link{learn_min_activity})
#' @param remove_inactive logical, if TRUE inactive fragments are removed. Default to TRUE.
#'
#' @return
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export compute_cooperativity
#'
#'
compute_cooperativity <- function(tib_comb, tib_basal, signal_t, remove_inactive = TRUE) {

  # validate args
  if(remove_inactive & missing(signal_t))
    stop('Please provide minimum activity threshold (see argument signal_t)')

  # generate key pair to extract basal activities of frag1/frag2
  tib_basal_act <- tib_comb %>%
    # add temp ids matching basal library id for each element of pair
    mutate(id_frag1 = paste0(frag1, strand1, frag1, strand1),
           id_frag2 = paste0(frag2, strand2, frag2, strand2)) %>%
    dplyr::select(id_frag1, id_frag2) %>%
    # extract activities basal frag 1
    left_join(dplyr::select(tib_basal, id, starts_with('activity')),
              by = c("id_frag1" = "id")) %>%
    # extract activities basal frag 2
    left_join(dplyr::select(tib_basal, id, starts_with('activity')),
              by = c("id_frag2" = "id"),
              suffix = c('_frag1', '_frag2')) %>%
    dplyr::select(-c(id_frag1, id_frag2))

  # add basal activities to comb
  tib_comb <- bind_cols(tib_comb, tib_basal_act)

  # extract columns to compute cooperativity indices
  #    _all suffix = cooperativity index on averaged activities
  # extract numerator
  numerator <- tib_comb %>%
    dplyr::select(matches('activity_br\\d$'), activity_all)

  # extract denominator (part1: basal activity fragment1)
  den_frag1 <- tib_comb %>%
    dplyr::select(ends_with('_frag1'), activity_all_frag1)

  # extract denominator (part2: basal activity fragment2)
  den_frag2 <- tib_comb %>%
    dplyr::select(ends_with('_frag2'), activity_all_frag2)

  # compute denominator
  denominator <- den_frag1 + den_frag2

  # compute cooperative index
  coop_add <- log2(numerator / denominator)

  # compute boost index
  boost    <- log2(numerator / den_frag2)

  # rename cols
  names(coop_add) <-  str_replace(names(coop_add), 'activity', 'coop_add')
  names(boost)    <-  str_replace(names(boost), 'activity', 'boost')

  # add cooperativity indices and boost indices to comb
  tib_comb <- bind_cols(tib_comb, coop_add, boost)

  # flag active elements
  tib_comb <- tib_comb %>%
    mutate(active = activity_all >= signal_t)

  # if remove_inactive, filter by combinatorial activity
  if(remove_inactive) {
    tib_comb <- tib_comb %>%
      filter(active == TRUE)
  }

  tib_comb
}


#' @title Wrapper function to automatically process iPCR-ECN merged data and obtain annotated cooperativity tibbles for downstream analyses
#'
#' @usage auto_process(tib_basal, tib_comb, tib_dat, min_pdna, min_n_bc, avg_type, signal_t)
#'
#' @param tib_basal tibble, containing merged basal library fragments (see \link{merge_ipcr_ecn})
#' @param tib_comb tibble, containing merged combinatorial library fragments (see \link{merge_ipcr_ecn})
#' @param tib_dat tibble, containing the DAT design, as returned by \link{read_dat_design}
#' @param min_pdna integer, the pDNA count threshold to be used for filtering (passed to \link{combine_cn})
#' @param min_n_bc integer, minimum number of different barcodes to be used for filtering (passed to \link{filter_cn})
#' @param avg_type character, if 'wa' barcode-level activities are summarized using a weighted average (weights proportional to normalized pDNA counts). If 'avg' barcodes are summarized using an arithmetic average (passed to \link{summarize_barcodes})
#' @param signal_t numeric, the signal threshold to be used for classifying active/inactive pairs in the combinatorial library. If missing, this threshold is estimated from the distribution of activity values
#'
#' @return A list of 3 tibbles: basal, unfiltered combinatorial (i.e. all inactive and active pairs), and filtered combinatorial (active pairs only) tibbles, and one numeric (the activity threshold used to classify active and inactive pairs in the combinatorial library)
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export auto_process
#'
#'
auto_process <- function(tib_basal, tib_comb, tib_dat, min_pdna, min_n_bc, avg_type, signal_t) {

  # sum pdna counts across replicates
  tib_basal    <- combine_cn(tib_basal)
  tib_comb     <- combine_cn(tib_comb)

  # remove barcodes with pDNA reads < threshold
  tib_basal    <- filter_cn(tib_basal, min_pdna = min_pdna)
  tib_comb     <- filter_cn(tib_comb, min_pdna = min_pdna)

  # remove barcodes of elements with < threshold distinct barcodes
  tib_basal    <- filter_barcodes(tib_basal, min_n_bc = min_n_bc,  main = 'Basal')
  tib_comb     <- filter_barcodes(tib_comb, min_n_bc = min_n_bc,  main = 'Combinatorial')

  # compute offsets
  offsets_basal <- tib_basal %>%
    dplyr::select(contains('dna_counts')) %>%
    colSums() / 1e6
  names(offsets_basal) <- names(offsets_basal) %>%
    str_replace('_counts', '')

  message('Basal sum', offsets_basal)

  offsets_comb <- tib_comb %>%
    dplyr::select(contains('dna_counts')) %>%
    colSums() / 1e6
  names(offsets_comb) <- names(offsets_comb) %>%
    str_replace('_counts', '')

  message('Combinatorial sum', offsets_comb)

  # normalize to library sizes
  tib_basal    <- normalize_counts(tib_basal, offsets_basal)
  tib_comb     <- normalize_counts(tib_comb, offsets_comb)

  # compute activities and summarize barcodes
  tib_basal    <- compute_activities(tib_basal)
  tib_comb     <- compute_activities(tib_comb)

  # summarize activities (weighted average)
  tib_basal    <- summarize_barcodes(tib_basal, type = avg_type)
  tib_comb     <- summarize_barcodes(tib_comb, type = avg_type)

  if(missing(signal_t)) {

    # model combinatorial activity distributions
    signal_t     <- learn_min_activity(tib_comb)

  }

  # compute cooperativity
  tib_comb_all <- compute_cooperativity(tib_comb, tib_basal, signal_t = signal_t, remove_inactive = FALSE)
  tib_comb     <- compute_cooperativity(tib_comb, tib_basal, signal_t = signal_t, remove_inactive = TRUE)

  # add metadata
  tib_basal    <- add_metadata(tib_basal, tib_dat = tib_dat, type = 'basal')
  tib_comb     <- add_metadata(tib_comb, tib_dat = tib_dat, type = 'comb')
  tib_comb_all <- add_metadata(tib_comb_all, tib_dat = tib_dat, type = 'comb')

  # return list of tibs
  return(list('basal'    = tib_basal,
              'comb'     = tib_comb,
              'comb_all' = tib_comb_all,
              'signal_t' = signal_t))

}


#' @title Annotate fragments in the basal/combinatorial libraries by adding metadata (e.g. class, genomic coordinates and distance)
#'
#' @usage add_metadata(tib, tib_dat, type = 'basal')
#'
#' @param tib tibble, containing cooperativity values as returned by \link{compute_cooperativity}
#' @param tib_dat tibble, fragment coordinates and metadata as returned by \link{read_dat_design}
#' @param type character, one of 'basal' (for basal library') or 'comb' (for combinatorial library)
#'
#' @return a tibble
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export add_metadata
#'
#'
add_metadata <- function(tib, tib_dat, type = 'basal') {

  # validate args
  stopifnot(type %in% c('basal', 'comb'))

  if(type == 'basal') {
    tib <- tib %>%
      dplyr::rename(frag = frag1, strand = strand1) %>%
      dplyr::select(-c(frag2, strand2)) %>%
      mutate(id    = paste0(frag, strand),
             class = paste0(substr(id, 1, 1))) %>%
      left_join(tib_dat, by = 'frag') %>%
      dplyr::select(id, class, frag, strand, seqnames, start, end, starts_with('activity'))
  }

  else {
    tib <- tib %>%
      mutate(id1   = paste0(frag1, strand1),
             id2   = paste0(frag2, strand2),
             id    = paste0(id1, id2),
             class = paste0(substr(id1, 1, 1), substr(id2, 1, 1))) %>%
      # add genomic coordinates
      left_join(tib_dat, by = c('frag1' = 'frag')) %>%
      dplyr::rename(seqnames1 = seqnames, start1 = start, end1 = end) %>%
      left_join(tib_dat, by = c('frag2' = 'frag')) %>%
      dplyr::rename(seqnames2 = seqnames, start2 = start, end2 = end) %>%
      # group, trick essentially rowwise()
      group_by(id1, id2) %>%
      # distances for trans pairs is set to Inf
      mutate(dist = ifelse(seqnames1 == seqnames2,
                           min(abs(end1 - start2), abs(end2 - start1)), Inf)) %>%
      # reorder to final shape
      dplyr::select(id, class,
                    id1, frag1, strand1, seqnames1, start1, end1,
                    id2, frag2, strand2, seqnames2, start2, end2,
                    dist, starts_with('activ'), starts_with('boost'), starts_with('coop')) %>%
      ungroup
  }

  tib
}


#' @title Count reads from BAM file within a set of query regions
#'
#' @usage get_signal_bam(query_gr, bam_fn, width = NULL, overlapping = TRUE, paired_end = FALSE, map_qual = 20, frag_len = 0, strand = 'both', rpm = FALSE)
#'
#' @param query_gr GRanges object, query genomic regions for quantification (e.g. coordinates of genomic fragments in basal library)
#' @param bam_fn character, (full) path to BAM file. This must be indexed, i.e. a .bai file must be located in the same directory
#' @param width integer, if specified, query genomic regions will be resized to width
#' @param overlapping logical, if FALSE overlapping ranges in the query will be discarded. Default to TRUE.
#' @param paired_end logical, if TRUE the BAM file contains paired-end reads and only the 5' position of the first read in a proper mapped pair will be considered (SAM flag 66). Default to FALSE (i.e. single end).
#' @param map_qual integer, minimum read mapping quality. Default to 20.
#' @param frag_len integer, the approximate average fragment length. Default to 0, i.e. no shift of 5' read position is performed.
#' @param strand character, the count mode. One of 'sense', 'antisense' or 'both'. Default to 'both', i.e. the sum of sense and antisense counts is returned.
#' @param rpm logical, if TRUE, reads per million are returned instead of raw counts. Library sizes are computed internally.
#'
#' @return
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export get_signal_bam
#'
#'
get_signal_bam <- function(query_gr, bam_fn, width = NULL, overlapping = TRUE, paired_end = FALSE, map_qual = 20, frag_len = 0, strand = 'both', rpm = FALSE) {

  # validate args
  stopifnot(strand %in% c('sense', 'antisense', 'both'))

  # if width provided, resize
  if(!is.null(width))  {
    query_gr <- resize(query_gr, width = width, fix = 'center')
  }

  # if not overlapping, remove overlapping ranges from query
  if(!overlapping) {
    isolated <- as.numeric(which(table(queryHits(findOverlaps(query_gr, ignore.strand = TRUE))) == 1))
    subject  <- subject[isolated]
  }

  # count reads within query ranges
  out <- bamCount(bam_fn,
                  query_gr,
                  mapqual    = map_qual,
                  shift      = round(frag_len / 2),
                  ss         = TRUE,
                  paired.end = ifelse(paired_end, 'filter', 'ignore'),
                  verbose    = FALSE)

  # extract relevant count column based on strand param
  out <- switch(strand,
                both = colSums(out),
                sense = out['sense', ],
                antisense = out['antisense', ])

  # if rpm, count total number of reads within query chromosomes (same filtering as query)
  if(rpm) {
    lib_size <- bamCount(bam_fn,
                         gr_chrom_sizes_mm10,
                         mapqual    = map_qual,
                         shift      = round(frag_len / 2),
                         ss         = TRUE,
                         paired.end = ifelse(paired_end, 'filter', 'ignore'),
                         verbose    = FALSE)
    lib_size <- sum(lib_size) / 1e6

    message('Computed library size: ', signif(lib_size, 5), ' mio. reads')

    # compute rpm
    out <- out / lib_size
  }

  out
}


#' Filter combinatorial library by 3D interactions, integrating Capture Hi-C data
#'
#' @usage get_interacting_pairs(tib, gi_chic, gr_bait, class = 'all', type = 'add')
#'
#' @param tib tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#' @param gi_chic GInteractions object, containing Capture Hi-C interactions (and their CHiCAGO score, encoded as -log10(p-val))
#' @param gr_bait GRanges, containing the genomic coordinates of all Capture Hi-C probes used for the experiment
#' @param class character specifying the class of pairs of interest (default to all considers all pairs)
#' @param type character, can be either 'add' or 'hsa' for additive and highest-single activity index, respectively
#'
#' @return a tibble, with an additional column (contact, logical) annotating hits
#'
#' @note The function distinguishes between non-interacting and not-probed pairs. The latter are filtered out.
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export get_interacting_pairs
#'
#'
get_interacting_pairs <- function(tib, gi_chic, gr_bait, class = 'all', type = 'add') {

  # validate args
  if(!class %in% c('all', 'EE', 'EP', 'PE', 'PP'))
    stop('Undefined class type. Please use one of EE, EP, PE or PP, or leave default for all pairs')

  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  if(class != 'all') {
    # note: tib %>% filter(class == get('class')) fails
    # see https://stackoverflow.com/questions/40169949/filter-dataframe-using-global-variable-with-the-same-name-as-column-name

    tib     <- tib[tib[['class']] == class, ]
  }

  # init chic_score in input tibble
  tib <- tib %>%
    mutate(chic_score = 0)

  # element coordinates -> GRanges
  element_coord <- tib_to_gr(tib)

  # generate query GInteractions object based on element coordinates
  gi_query  <- GInteractions(element_coord[[1]], element_coord[[2]])

  # find 2D overlaps between query and chic interactions
  olaps     <- findOverlaps(gi_query, gi_chic)

  # retrieve chic scores from subject
  score_vec <- gi_chic[subjectHits(olaps)]$score

  # multiple hits possible for each interaction in query (e.g. reciprocal or spanning interaction)
  # split and summarize scores (mean) by query interaction
  score_vec <- lapply(split(score_vec, queryHits(olaps)), mean) %>%
    unlist

  # add scores to query interaction hits
  query_pos <- as.integer(names(score_vec))
  tib[['chic_score']][query_pos] <- score_vec

  # identify pairs where at least one element was baited
  chic_probed <- (element_coord[[1]] %over% gr_bait | element_coord[[2]] %over% gr_bait)

  tib[['probed']] <- chic_probed

  message('Note: ', sum(!chic_probed), ' elements not probed in CHi-C data.')

  # filter by pairs that have been probed
  tib <- tib %>%
    filter(probed == TRUE) %>%
    select(-probed)

  tib
}


#' Annotate pairs with respect to TAD coordinates (define intra- and inter-TAD pairs)
#'
#' @usage get_tad_localization(tib_comb, tib_basal, tad_coord)
#'
#' @param tib_comb tibble, containing combinatorial library fragments
#' @param tib_basal tibble, containing basal library fragments
#' @param tad_coord GRanges, containing the genomic coordinates of TADs
#'
#' @return a tibble, with an additional annotation column (intra_tad, logical)
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export get_tad_localization
#'
#'
get_tad_localization <- function(tib_comb, tib_basal, tad_coord) {

  # for each tad, list basal elements therein (ids)
  gr_basal  <- tib_to_gr(tib_basal)
  id_list   <- lapply(seq_along(tad_coord), function(i) subsetByOverlaps(gr_basal, tad_coord[i])$id)

  # extract indices of all pairs localizing within a tad (intra)
  idx_intra <- lapply(id_list, function(ids) {
    tib_comb[['id1']] %in% ids & tib_comb[['id2']] %in% ids }) %>%
    do.call('cbind', .) %>%
    apply(1, any)

  # add intra_tad column to tib_comb
  tib_comb %>%
    mutate(intra_tad = idx_intra)

}


#' Generate PWM feature matrix from FIMO output file
#'
#' @usage get_pwm_feature_matrix(motif_meta_fn, fimo_fn, db = 2)
#'
#' @param motif_meta_fn character, the motif metadata file name (full path). The metadata are expected to contain a 'PWM.ID' and a 'Cognate.TF' annotation columns
#' @param fimo_fn character, the FIMO output file name (full path)
#' @param db integer, the version of the internal database that was used for the scoring. Use a value of 1 for the original database Diaferia et al. 2016 (maintained for backward compatibility). Default to 2, i.e. the latest and extended database from the Natoli lab.
#'
#' @return a tibble with N motifs + 1 (sequence id) columns
#'
#' @note Metadata for the TF motif collection from Diaferia et al: `/home/f.comoglio/mydata/Annotations/TFDB/Curated_Natoli/motif_metadata.csv`.
#' Metadata for database version 2: `/home/f.comoglio/mydata/Annotations/TFDB/Curated_Natoli/update_2017/fc181127_curated_metadata_no_composite_filt.csv`
#'
#' @keywords core
#'
#' @export get_pwm_feature_matrix
#'
#'
get_pwm_feature_matrix <- function(motif_meta_fn, fimo_fn, db = 2) {

  # validate args
  valid_dbs <- 1:2
  if(!db %in% valid_dbs)
    stop('Invalid db (database version). Please use db=1 (maintained for backward compatibility only) or db=2')

  # db=1 is maintained for backward compatibility only
  if(db == 1) {

    # read in motif metadata
    motif_meta    <- read.csv(motif_meta_fn)

    # check whether motif metadata contain essential annotations
    if(!all(c('PWM.ID', 'Cognate.TF') %in% colnames(motif_meta))) {
      message('The motif metadata file does not contain the essential columns PWM.ID and Cognate.TF')
    }

    motif_minimal <- motif_meta[, c('PWM.ID', 'Cognate.TF')]

    # load fimo output --> extract motif id, sequence id and p-value
    df <- read.table(fimo_fn)
    df <- df[, c(1, 2, 7)]

    colnames(df) <- c('PWM.ID', 'seqid', 'pval')

    # add TF id
    df <- merge(df, motif_minimal, by = 'PWM.ID')

    # group motif hits by sequence id
    l <- split(df, df[['seqid']])

    # multiple PWM and multiple hits possible. Reduce hits to one per TF, keeping best p-val only
    l <- lapply(l, function(x) {
      x_by_tf <- split(x, x[['Cognate.TF']], drop = TRUE)
      x_by_tf <- lapply(x_by_tf, function(y) y[which.min(y$pval), ])
      do.call('rbind', x_by_tf)
    })

    # initialize feature matrix
    n_tf          <- motif_minimal[['Cognate.TF']] %>%
      unique %>%
      length
    n_seq         <- length(l)
    pwm           <- matrix(1, nrow = n_seq, ncol = n_tf)
    colnames(pwm) <- (motif_minimal[['Cognate.TF']] %>% unique)

    # replace :: from names of composite motifs
    colnames(pwm) <- str_replace_all(colnames(pwm), '::', '_')

    # fill in feature matrix
    for(i in 1 : n_seq) {
      pwm[i, l[[i]][['Cognate.TF']]] <- l[[i]]$pval
    }

    # -log10 transform
    pwm           <- -1 * log10(pwm)

    # coerce to tib and return
    tib_fimo <- as_data_frame(pwm) %>%
      mutate(id = names(l),
             prefix = str_sub(id, 1, 1),
             suffix = str_extract(id, '_.*'),
             id = str_remove(id, '[EP]'),
             id = str_extract(id, '.*_'),
             id = str_remove(id, '_'),
             id = str_pad(id, width = 3, pad = '0'),
             id = paste0(prefix, id, suffix)) %>%
      dplyr::select(-c(prefix, suffix)) %>%
      dplyr::select(id, everything())

  }

  # db = 2 (default)
  else {

    # load metadata
    tib_meta    <- read_csv(motif_meta_fn) %>%
      # extract tf symbol from motif id (Cognate_TF unsafe, it can be empty) and replace :: occurrences
      mutate(tf_symbol = str_remove(ID, '_[0-9]*'),
             tf_symbol = str_replace(tf_symbol, '::', '_')) %>%
      select(motif_id = `PWM ID`, tf_symbol)

    # load fimo results
    tib_fimo <- read_tsv(fimo_fn) %>%
      # extract motif id, sequence id and p-value
      select(motif_id, sequence_name, pval = `p-value`)

    # add tf symbol to fimo results
    tib_fimo <- tib_fimo %>%
      left_join(tib_meta, by = 'motif_id') %>%
      # remove hits with missing motif id (composite pwms)
      filter(!is.na(tf_symbol))

    # select best hit for each motif and sequence
    tib_fimo <- tib_fimo %>%
      group_by(sequence_name, tf_symbol) %>%
      dplyr::slice(which.min(pval)) %>%
      ungroup()

    # spread into feature matrix
    tib_fimo <- tib_fimo %>%
      mutate(pval = -1 * log10(pval)) %>%
      select(-motif_id) %>%
      spread(key = tf_symbol, value = pval, fill = 0, drop = TRUE) %>%
      # perform cosmetics on the id
      mutate(prefix = str_sub(sequence_name, 1, 1),
             suffix = str_extract(sequence_name, '_.*'),
             id     = str_remove(sequence_name, '[EP]'),
             id     = str_extract(id, '.*_'),
             id     = str_remove(id, '_'),
             id     = str_pad(id, width = 3, pad = '0'),
             id     = paste0(prefix, id, suffix)) %>%
      select(-c(sequence_name, prefix, suffix)) %>%
      select(id, everything())

  }

  return(tib_fimo)

}


#' Generate PWM feature matrix (group TF by family) from FIMO output file
#'
#' @usage get_pwm_feature_matrix_by_family(motif_meta_fn, fimo_fn)
#'
#' @param motif_meta_fn character, the motif metadata file name (full path). The metadata are expected to contain a 'PWM.ID', a 'Cognate.TF' and a 'Family' annotation columns
#' @param fimo_fn character, the FIMO output file name (full path)
#'
#' @return a list of two tibbles: a tibble with N families + 1 (sequence id) columns, and a tibble with parsed PWM metadata
#'
#' @note Metadata for the TF motif collection from Diaferia et al: `/home/f.comoglio/mydata/Annotations/TFDB/Curated_Natoli/motif_metadata.csv`.
#' Metadata for database version 2: `/home/f.comoglio/mydata/Annotations/TFDB/Curated_Natoli/update_2017/fc181127_curated_metadata_no_composite_filt.csv`
#'
#' @keywords core
#'
#' @export get_pwm_feature_matrix_by_family
#'
#'
get_pwm_feature_matrix_by_family <- function(motif_meta_fn, fimo_fn) {

  # load metadata
  tib_meta    <- read_csv(motif_meta_fn) %>%
    # extract tf symbol from motif id (Cognate_TF unsafe, it can be empty) and replace :: occurrences
    mutate(tf_symbol = str_remove(ID, '_[0-9]*'),
           tf_symbol = str_replace(tf_symbol, '::', '_')) %>%
    # cleanup family names
    mutate(family = str_replace_all(Family, ' *[Ff]actor[s]?$', ''), # opt: Class
           family = str_replace_all(family, '/|-| ', '_')) %>%
    select(motif_id = `PWM ID`, tf_symbol, family)

  # load fimo results
  tib_fimo <- read_tsv(fimo_fn) %>%
    # extract motif id, sequence id and p-value
    select(motif_id, sequence_name, pval = `p-value`)

  # add tf symbol and family to fimo results
  tib_fimo <- tib_fimo %>%
    left_join(tib_meta, by = 'motif_id') %>%
    # remove hits with missing motif id (composite pwms)
    filter(!is.na(tf_symbol))

  # select best hit for each family and sequence
  tib_fimo <- tib_fimo %>%
    group_by(sequence_name, family) %>%
    dplyr::slice(which.min(pval)) %>%
    ungroup()

  # spread into feature matrix
  tib_fimo <- tib_fimo %>%
    mutate(pval = -1 * log10(pval)) %>%
    select(-motif_id, -tf_symbol) %>%
    spread(key = family, value = pval, fill = 0, drop = TRUE) %>%
    # perform cosmetics on the id
    mutate(prefix = str_sub(sequence_name, 1, 1),
           suffix = str_extract(sequence_name, '_.*'),
           id     = str_remove(sequence_name, '[EP]'),
           id     = str_extract(id, '.*_'),
           id     = str_remove(id, '_'),
           id     = str_pad(id, width = 3, pad = '0'),
           id     = paste0(prefix, id, suffix)) %>%
    select(-c(sequence_name, prefix, suffix)) %>%
    select(id, everything())

  return(list(tib_fimo = tib_fimo, tib_meta = tib_meta))

}


#' Screen homotypic TF motif pairs for significant association with cooperativity
#'
#' @usage screen_tf(tib, tf_id_vec, tib_expr)
#'
#' @param tib_comb tibble, containing combinatorial library fragments and motif scores (as returned by \link{add_motif_score})
#' @param tf_id_vec character, vector of TF identifiers. These should match the prefix of the motif score columns in `tib_comb`.
#' @param tib_expr tibble, containing gene expression values to be considered (e.g. FPKM, regularized log expression) in the `expr_mean` column. If provided, TF expression levels will be extracted and added as a new column to the output tibble
#' @return a tibble with 4 or 5 columns: id (TF motif identifier from input tf_id_vec), type (broad or self-compatibility), effect size, BH-adjusted p-values (FDR), mean TF expression value (if `tib_expr` is provided)
#'
#' @note None.
#'
#' @keywords core
#'
#' @export screen_tf
#'
#'
screen_tf <- function(tib, tf_id_vec, tib_expr) {

  # init median/pval/n output vectors
  # suffix 0: 1 vs 0 comparison
  # suffix 1: 2 vs 1 comparison
  n_tf       <- length(tf_id_vec)
  med_vec_0  <- rep(Inf, n_tf)
  med_vec_1  <- rep(Inf, n_tf)
  n_vec_0    <- rep(0, n_tf)
  n_vec_1    <- rep(0, n_tf)
  pval_vec_0 <- rep(1, n_tf)
  pval_vec_1 <- rep(1, n_tf)

  # add tf ids
  names(med_vec_0) <- names(pval_vec_0) <- names(n_vec_0) <- tf_id_vec
  names(med_vec_1) <- names(pval_vec_1) <- names(n_vec_1) <- tf_id_vec

  for(tf_id in tf_id_vec) {

    # generate colnames to match
    tf_id1 <- paste0(tf_id, '_frag1')
    tf_id2 <- paste0(tf_id, '_frag2')

    # create a symb
    col1   <- rlang::sym(tf_id1)
    col2   <- rlang::sym(tf_id2)

    # extract cols and count instances (!! to unquote symb)
    tib_plt <- tib %>%
      rowwise() %>%
      mutate(n = sum((!!col1) > 0, (!!col2) > 0)) %>%
      dplyr::select(n, coop_add)

    # group coop by number of instances
    l <- split(tib_plt[['coop_add']], tib_plt[['n']])

    # compute median coop by group
    med_by_group <- sapply(l, median, na.rm = TRUE)

    # test significance (iff exists group 2 & >=5 data points)
    if(length(med_by_group) == 3) {

      if(length(l$`2`) >= 5) {

        # wilcoxon test + extract p-value
        pval_0            <- wilcox.test(l$`0`, l$`1`)$p.value
        pval_1            <- wilcox.test(l$`1`, l$`2`)$p.value

        pval_vec_0[tf_id] <- pval_0
        pval_vec_1[tf_id] <- pval_1

      }
    }

    # count min number of pairs contributing to each comparison
    n_0 <- min(length(l$`0`), length(l$`1`))
    n_1 <- min(length(l$`1`), length(l$`2`))

    n_vec_0[tf_id] <- n_0
    n_vec_1[tf_id] <- n_1

    # compute effect size: delta median coop
    med_vec_0[tf_id] <- med_by_group[2] - med_by_group[1]
    med_vec_1[tf_id] <- med_by_group[3] - med_by_group[2]
  }

  # adjust p-vals (BH)
  pval_vec_0 <- p.adjust(pval_vec_0, method = 'BH')
  pval_vec_1 <- p.adjust(pval_vec_1, method = 'BH')

  # format output
  tib <- tibble(id          = rep(tf_id_vec, 2),
                type        = factor(rep(c('broad', 'self'), each = n_tf)),
                effect_size = c(med_vec_0, med_vec_1),
                fdr         = c(pval_vec_0, pval_vec_1),
                n_min       = c(n_vec_0, n_vec_1))

  # if expression data provided, add expression values
  if(!missing(tib_expr)) {

    tib <- tib %>%
      left_join(select(tib_expr, symbol, expr_mean), by = c('id' = 'symbol'))

  }

  return(tib)
}


#' Screen heterotypic TF motif pairs for significant association with cooperativity
#'
#' @usage screen_heterotypic_tf(tib, tf_id_vec, tib_expr, expr_cutoff = 1)
#'
#' @param tib_comb tibble, containing combinatorial library fragments and motif scores (as returned by \link{add_motif_score})
#' @param tf_id_vec character, vector of TF identifiers. These should match the prefix of the motif score columns in `tib_comb`.
#' @param tib_expr tibble, containing gene expression values to be considered (e.g. FPKM, regularized log expression) in the `expr_mean` column.
#' @param expr_cutoff numeric, the expression cutoff to be used for filtering out non-expressed TFs. Only TFs with expression >= `expr_cutoff`` will be considered.
#' @return a tibble
#'
#' @note None.
#'
#' @keywords core
#'
#' @export screen_heterotypic_tf
#'
#'
screen_heterotypic_tf <- function(tib, tf_id_vec, tib_expr, expr_cutoff = 1) {

  # define internal utility function to screen a single tf pair
  # tib: a combinatorial tibble
  # tf1_id, tf2_id: gene symbol of the tfs in the heterotypic combination to be tested
  test_heterotypic_combination <- function(tib, tf1_id, tf2_id) {

    # generate colnames prefix to match (ensures only the tf id is matched)
    # e.g. CTCF but not CTCFL
    tf1_id_prefix <- paste0(tf1_id, '_')
    tf2_id_prefix <- paste0(tf2_id, '_')

    # select tf cols and define 4 classes:
    #  null: no tf1, tf2 motif hits
    #  tf1:  tf1 motif hit only (at either element)
    #  tf2:  tf2 motif hit only (at either element)
    #  tf12: tf1 motif within one element AND tf2 motif within the other element
    tib <- tib %>%
      select(starts_with(tf1_id_prefix), starts_with(tf2_id_prefix), coop_add) %>%
      mutate_at(1:4, as.logical) %>%
      mutate(null = (.[[1]] + .[[2]] + .[[3]] + .[[4]]) == 0,
             tf1  = (.[[1]] | .[[2]]) & !(.[[3]] | .[[4]]),
             tf2  = (.[[3]] | .[[4]]) & !(.[[1]] | .[[2]]),
             tf12 = (.[[1]] & .[[4]]) | (.[[2]] & .[[3]])) %>%
      select(null, tf1, tf2, tf12, coop_add) %>%
      # tall format
      gather(key = class, value = hit, ... = -coop_add) %>%
      filter(hit == TRUE) %>%
      select(-hit)

    # check whether:
    #   1. all classes represented
    #   2. >= 10 obs per class
    tib_n <- tib %>%
      group_by(class) %>%
      tally()

    if(nrow(tib_n) < 4 | any(tib_n[['n']] <= 10)) {

      # return NA
      tib_out <- tibble(es_null = NA, es_one = NA, pval_null = NA, pval_one = NA, n_null = NA, n_one = NA)

    }
    else {

      # summarize, run tests, add effect size, p-value and number of events
      tib_out <- tib %>%
        summarize_at(1, funs(
          es_null     = median(.[class == 'tf12'], na.rm = TRUE) - median(.[class == 'null'], na.rm = TRUE),
          # two candidates (tf12-tf1 and tf12-tf2)
          es_cand1    = median(.[class == 'tf12'], na.rm = TRUE) - median(.[class == 'tf1'], na.rm = TRUE),
          es_cand2    = median(.[class == 'tf12'], na.rm = TRUE) - median(.[class == 'tf2'], na.rm = TRUE),
          pval_null   = wilcox.test(.[class == 'null'], .[class == 'tf12'])$p.value,
          pval_cand1  = wilcox.test(.[class == 'tf1'], .[class == 'tf12'])$p.value,
          pval_cand2  = wilcox.test(.[class == 'tf2'], .[class == 'tf12'])$p.value,
          n_null      = length(.[class == 'null']),
          n_cand1     = length(.[class == 'tf1']),
          n_cand2     = length(.[class == 'tf2']),
          n_two       = length(.[class == 'tf12'])
        )) %>%
        # select best performing candidate (least significant test)
        rowwise() %>%
        mutate(es_one    = c(es_cand1, es_cand2)[which.max(c(pval_cand1, pval_cand2))],
               n_one     = min(c(n_cand1, n_cand2)[which.max(c(pval_cand1, pval_cand2))], n_two),
               pval_one = max(pval_cand1, pval_cand2)) %>%
        ungroup() %>%
        # remove temporary cols
        select(-contains('cand'), -n_two)

    }

    # add tf pair and rearrange
    tib_out %>%
      mutate(tf_pair = paste0(tf1_id, '::', tf2_id)) %>%
      select(tf_pair, everything())

  }


  # start tf screen
  # if expression data provided, remove non-expressed tfs
  if(!missing(tib_expr)) {

    message('Removing non-expressed TFs')

    # get expressed tfs
    tib_expr <- tib_expr %>%
      filter(expr_mean >= expr_cutoff)

    # remove non-expressed tfs from input vector
    tf_id_vec <- tf_id_vec[ tf_id_vec %in% tib_expr[['symbol']] ]

    message('...# expressed TFs:', length(tf_id_vec))
  }

  # generate all possible pairwise combinations (no homotypic)
  mat_pairs <- gtools::combinations(n = length(tf_id_vec), r = 2, v = tf_id_vec, repeats.allowed = FALSE)
  n_pairs   <- nrow(mat_pairs)

  # init output list
  l_out     <- vector(mode = 'list', length = n_pairs)

  message('...Testing ', n_pairs, ' pairs')

  # screen pairs
  for(i in 1 : n_pairs) {

    l_out[[i]] <- test_heterotypic_combination(tib, tf1_id = mat_pairs[i, 1], tf2_id = mat_pairs[i, 2])

  }

  # coerce to tibble
  as_tibble(do.call('rbind', l_out)) %>%
    # discard null tests
    filter(!is.na(es_null)) %>%
    # BH adjust p-val
    mutate(pval_null = p.adjust(pval_null, method = 'BH'),
           pval_one  = p.adjust(pval_one, method = 'BH'))

}
