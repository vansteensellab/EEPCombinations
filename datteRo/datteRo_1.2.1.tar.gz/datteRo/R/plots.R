

#' @title Plot barcode count distribution for iPCR libraries
#'
#' @usage plot_bc_distribution(tib, type = 'basal')
#'
#' @param tib tibble, containing basal or combinatorial iPCR library elements (imported with \link{read_ipcr})
#' @param type character, one of 'basal' (input is basal library) or 'comb' (input is combinatorial library)
#'
#' @return Called for its effect, returns 4 panels
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_bc_distribution
#'
#'
plot_bc_distribution <- function(tib, type = 'basal') {

  stopifnot(type %in% c('basal', 'comb'))

  if(type == 'basal') {
    # distribution of barcode counts - histogram
    p1 <- ggplot(tib, aes(ipcr_counts)) +
      geom_histogram() +
      labs(x = 'Read counts', y = '#Barcodes') +
      theme_bw()

    # distribution of barcode counts - ecdf
    p2 <- ggplot(tib, aes(ipcr_counts)) +
      stat_ecdf(geom = "step") +
      labs(x = 'Read counts', y = 'Fraction of barcodes') +
      theme_bw()

    # aggregate data by fragment (directional)
    tib_aggr <- tib %>%
      group_by(id) %>%
      summarise(n_bc = n_distinct(barcode),
                n_reads = sum(ipcr_counts),
                mu_counts = mean(ipcr_counts),
                sd_counts = sd(ipcr_counts)) %>%
      arrange(desc(n_bc))

    # distribution of no. barcodes per fragment
    p3 <- tib_aggr %>%
      mutate(n_bc = log2(n_bc)) %>%
      ggplot(aes(n_bc)) +
        geom_histogram() +
        labs(x = '#Distinct barcodes (log2)', y = '#Fragments') +
        theme_bw()

    # cumulative read count per fragment
    p4 <- tib_aggr %>%
      arrange(desc(n_reads)) %>%
      mutate(n_cum = cumsum(n_reads)) %>%
      ggplot(aes(n_cum, 1 : length(n_cum))) +
        geom_line() +
        labs(x = 'Cumulative read counts', y = 'Cumulative # of fragments') +
        theme_bw()

    grid.arrange(p1, p2, p3, p4, nrow = 2)
  } else {

    p1 <- tib %>%
      mutate(n_bc = log2(n_bc)) %>%
      ggplot(aes(n_bc)) +
        geom_histogram() +
        xlab('#Distinct barcodes (log2)') +
        ylab('#Fragments') +
        theme_bw()

    p2 <- tib %>%
      ggplot(aes(mu_counts)) +
        geom_histogram() +
        xlab('Mean barcode read counts') +
        ylab('#Fragments') +
        theme_bw()

    p3 <- tib %>%
      ggplot(aes(sd_counts)) +
        geom_histogram() +
        xlab('Standard deviation of barcode read counts') +
        ylab('#Fragments') +
        theme_bw()

    p4 <- tib %>%
      arrange(desc(n_reads)) %>%
      mutate(n_cum = cumsum(n_reads)) %>%
        ggplot(aes(n_cum, 1 : length(n_cum))) +
          geom_line() +
          xlab('Cumulative read counts') +
          ylab('Cumulative # of fragments') +
          theme_bw()

     grid.arrange(p1, p2, p3, p4, nrow = 2)
  }
}


#' @title Plot orientation bias, based on the number of barcodes associated to elements in plus or minus orientation
#'
#' @usage plot_orientation_bias(tib)
#'
#' @param tib tibble, containing basal or combinatorial iPCR library elements (imported with \link{read_ipcr})
#'
#' @return Called for its effect, returns a scatter plot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_orientation_bias
#'
#'
plot_orientation_bias <- function(tib) {

  tib %>%
    group_by(frag1, strand1) %>%
    summarise(n_bc = n_distinct(barcode)) %>%
    spread(key = strand1, value = n_bc) %>%
# prev:    dcast(frag1 ~ strand1) %>%
    rename(plus = `+`, minus = `-`) %>%
    mutate(plus = log2(plus), minus = log2(minus)) %>%
    ggplot(aes(plus, minus)) +
      geom_point() +
      geom_smooth(method = lm) +
      labs(x = '#Barcodes (Plus, log2)', y = '#Barcodes (Minus, log2)') +
      theme_bw()
}


#' @title Given a combinatorial library, plot the number of combinations of each type, accounting for fragment identity and orientation (barplot)
#'
#' @usage plot_combination_type(tib)
#'
#' @param tib tibble, containing basal or combinatorial iPCR library elements (imported with \link{read_ipcr})
#'
#' @return Called for its effect, returns 3 panels
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_combination_type
#'
#'
plot_combination_type <- function(tib) {

  p1 <- tib %>%
    select(type, n_frag, n_dir) %>%
    melt %>%
    ggplot(aes(type, value, group = variable, fill = type)) +
      facet_wrap(~variable, labeller = labeller(variable = c(n_frag = 'Identity', n_dir = 'Identity + Orientation'))) +
      geom_col() +
      labs(x = 'Combination type', y = '#Combinations') +
      scale_fill_manual(values=c('orangered', 'orange', 'skyblue3', 'navyblue')) +
      theme_bw()

  p2 <- tib %>%
  ggplot(aes(type, n_bc, fill = type)) +
    geom_col() +
    labs(x = 'Combination type', y = '#Barcodes') +
    scale_fill_manual(values=c('orangered', 'orange', 'skyblue3', 'navyblue')) +
    theme_bw()

  p3 <- tib %>%
  ggplot(aes(type, n_reads, fill = type)) +
    geom_col() +
    labs(x = 'Combination type', y = '#Reads') +
    scale_fill_manual(values=c('orangered', 'orange', 'skyblue3', 'navyblue')) +
    theme_bw()

  # combine in grid layout
  ggdraw() +
    draw_plot(p1, x = 0, y = 0.5, width = 1, height = 0.5) +
    draw_plot(p2, x = 0, y = 0, width = 0.5, height = 0.5) +
    draw_plot(p3, x = 0.5, y = 0, width = 0.5, height = 0.5)
}


#' @title Given a combinatorial iPCR library, plot the iPCR matrix
#'
#' @usage plot_ipcr_matrix(tib, type, lab_frac = 0.25)
#'
#' @param tib tibble, containing basal or combinatorial iPCR library elements (imported with \link{read_ipcr})
#' @param type character, the matrix type: 'binary' produces a binary matrix plot (i.e. a pair is either present or absent, irrespective of orientation), 'orientations' fills the matrix with the number of orientations available for each pair, and 'barcodes' fills the matrix with the total number of barcodes available for each pair, irrespective of orientation
#' @param lab_frac numeric, the fraction of all labels to be shown (0 = no label, 1 = all labels). Default to 0.25 (works well with middle size matrices, consider increasing to 0.5 or even 1.0 for small submatrices)
#'
#' @return Called for its effect, returns a matrix plot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_ipcr_matrix
#'
#'
plot_ipcr_matrix <- function(tib, type, lab_frac = 0.25) {

  # validate args
  stopifnot(type %in% c('binary', 'orientations', 'barcodes'))
  stopifnot(lab_frac > 0 & lab_frac <= 1)

  if(type == 'binary') {
    hits <- tib %>%
      select(frag1, frag2) %>%
      distinct %>%
      mutate(present = factor(1))

    n_items <- hits %>%
      select(frag1) %>%
      n_distinct()

    spacing <- n_items / round(n_items * lab_frac)

    # plot heatmap (binary)
    p <- hits %>%
      ggplot(aes(x = frag1, y = frag2, color = present)) +
        geom_tile(size = 1e-6) +
        scale_color_manual(values = c("white", "black")) +
        labs(x = 'First in pair (barcode-distal)', y = 'Second in pair (barcode-proximal)', caption = '(Combinatorial library, all pairs)') +
        theme(axis.text.x = element_text(angle = 90, color =  c('black', rep('transparent', spacing))),
              axis.text.y = element_text(color =  c('black', rep('transparent', spacing))),
              legend.position = 'none')
    return(p)

  } else {

    hits <- tib %>%
      group_by(frag1, frag2) %>%
      summarise(n_or    = n_distinct(strand1, strand2),
                n_bc    = n_distinct(barcode),
                n_reads = sum(ipcr_counts)) %>%
      mutate(n_bc    = log10(n_bc),
             n_reads = log10(n_reads))

    n_items <- hits %>%
      select(frag1) %>%
      n_distinct()

    spacing <- n_items / round(n_items * lab_frac)

  }

  if(type == 'orientations') {
    p <- hits %>%
      ggplot(aes(x = frag1, y = frag2, fill = n_or)) +
        geom_tile(aes(fill = n_or)) +
        scale_fill_gradient(low = "skyblue",high = "black", name = '#Orient') +
        labs(x = 'First in pair (barcode-distal)', y = 'Second in pair (barcode-proximal)', caption = '(Combinatorial library, all pairs)') +
        theme(axis.text.x = element_text(angle = 90, color =  c('black', rep('transparent', spacing))),
              axis.text.y = element_text(color =  c('black', rep('transparent', spacing))))

    return(p)

  }

  if(type == 'barcodes') {
    p <- hits %>%
      ggplot(aes(x = frag1, y = frag2, fill = n_bc)) +
        geom_tile(aes(fill = n_bc)) +
        scale_fill_gradient(low = 'lightblue', high = 'blue4', name = 'log10(bc)') +
        labs(x = 'First in pair (barcode-distal)', y = 'Second in pair (barcode-proximal)', caption = '(Combinatorial library, all pairs)') +
        theme(axis.text.x = element_text(angle = 90, color =  c('black', rep('transparent', spacing))),
              axis.text.y = element_text(color =  c('black', rep('transparent', spacing))))

    return(p)
  }

}


#' @title Plot chord diagram (circos plot) of EP pairs within the combinatorial library
#'
#' @usage plot_ep_chord(tib, anchors = 'E', seed = 2017)
#'
#' @param tib tibble, containing combinatorial iPCR library elements (imported with \link{read_ipcr}) or summarized data
#' @param anchors character, specifying whether the anchors are enhancers ('E') or promoters ('P')
#' @param seed numeric, the random seed (ensures reproducible grid colors)
#'
#' @return Called for its effect, returns a chord diagram/circos plot
#'
#' @note The function automatically detects whether the input tibble contains barcode-level data (i.e. iPCR tibble) or summarized data (i.e. contains cooperativity indices)
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_ep_chord
#'
#'
plot_ep_chord <- function(tib, anchors = 'E', seed = 2017) {

  # validate args
  if(!anchors %in% c('E', 'P')) {
    stop('Invalid anchors parameter. Please use P to anchor your analysis on promoters, E for enhancers')
  }

  # set seed for randomizing grid colors
  set.seed(seed)

  # check whether input is iPCR or summarized tib
  if('barcode' %in% colnames(tib)) {

    # it's an iPCR tib
    # summarize number of barcodes by combination
    tib_ep <- tib %>%
      group_by(frag1, frag2) %>%
      summarise(value = n_distinct(barcode)) %>%
      # filter for EP only
      filter(str_sub(frag1, 1, 1) == 'E', str_sub(frag2, 1, 1) == 'P') %>%
      select(frag1, frag2, value)

  }

  else {

    # it's a summarized tib (contains coop index)
    tib_ep <- tib %>%
      # filter for EP only
      filter(str_sub(frag1, 1, 1) == 'E', str_sub(frag2, 1, 1) == 'P') %>%
      select(frag1, frag2, value = coop_add) %>%
      # drop NA coop
      filter(!is.na(value))

  }

  # prepare input tibble for circos
  if(anchors == 'E') {
    tib_ep <- tib_ep %>%
      rename(from = frag1, to = frag2)
  } else {
    tib_ep <- tib_ep %>%
      select(frag2, frag1, value) %>%
      rename(from = frag2, to = frag1)
  }

  #  return(tib_ep)

  # count E and P
  blocks <- unique(c(tib_ep[['from']], tib_ep[['to']]))
  n_e    <- length(grep('E', blocks))
  n_p    <- length(grep('P', blocks))

  # init color palette
  # + randomize
  grid_col <- wesanderson::wes_palette('Zissou1', type = 'continuous', n = n_e + n_p)
  grid_col <- sample(grid_col, length(grid_col))

  # define gap to separate E from P
  #  circos.par(gap.after = c(rep(1, n_p - 1), 5, rep(1, n_e - 1), 5))

  # prov: to fix what seems to be a bug
  if((n_e + n_p) %% 2 == 0) {
    if(anchors == 'E') {
      circos.par(gap.after = c(rep(1, n_e - 1), 5, rep(1, n_p - 1), 5))
    } else {
      circos.par(gap.after = c(rep(1, n_p - 1), 5, rep(1, n_e - 1), 5))
    }
  } else {
    if(anchors == 'E') {
      circos.par(gap.after = c(rep(1, n_e - 1), 5, rep(1, n_p - 1)))
    } else {
      circos.par(gap.after = c(rep(1, n_p - 1), 5, rep(1, n_e - 1)))
    }
  }

  # plot circos/chord diagram
  chordDiagram(tib_ep,
               annotationTrack   = 'grid',
               grid.col          = grid_col,
               preAllocateTracks = list(track.height = max(strwidth(unlist(dimnames(tib_ep))))))

  # customize sector labels in track 1
  circos.track(track.index = 1, panel.fun = function(x, y) {
    circos.text(CELL_META$xcenter,
                CELL_META$ylim[1],
                CELL_META$sector.index,
                facing = 'clockwise',
                niceFacing = TRUE,
                cex = 0.65,
                adj = c(0, 0.5)) },
    bg.border = NA)

}


#' @title Plot Gaussian mixture model fit
#'
#' @usage plot_gmm(vec, model, var.equal = FALSE, ...)
#'
#' @param vec numeric, the raw input vector used to fit the GMM (i.e. the input to Mclust)
#' @param model Mclust object, the model object returned by Mclust fit
#'
#' @return Called for its effect, returns a density plot
#'
#' @note Currently implemented for two-component GMMs only
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_gmm
#'
#'
plot_gmm <- function(vec, model) {

  # extract model params
  # first component
  pi1 <- model$parameters$pro[1]
  mu1 <- model$parameters$mean[1]
  sd1 <- sqrt(model$parameters$variance$sigmasq[1])
  # second component
  pi2 <- model$parameters$pro[2]
  mu2 <- model$parameters$mean[2]
  sd2 <- sqrt(model$parameters$variance$sigmasq[2])

  # plot histogram of input vector
  hist(vec, freq = FALSE, breaks = 50, col = 'gray90', main = '', xlab = 'X', border = NA)

  # add fitted curves
	curve(pi1 * dnorm(x, mu1, sd1), col = 'steelblue', lwd = 3, add = TRUE)
  curve(pi2 * dnorm(x, mu2, sd2), col = 'orangered', lwd = 3, add = TRUE)
}


#' @title Plot cooperativity index distributions for each class of pairs (density plots)
#'
#' @usage plot_coop_density(tib, type, sense_only = FALSE)
#'
#' @param tib tibble, containing combinatorial elements (post-summarization with \link{add_metadata})
#' @param type character, defines the cooperativity measure to be shown. Use 'add' for additive and 'hsa' for highest-single activity, respectively
#' @param sense_only logical, if TRUE, pairs containing promoters in antisense orientation (in either position) are removed prior to density estimation. Default to FALSE.
#'
#' @return Called for its effect, returns 4 density plots
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_density
#'
#'
plot_coop_density <- function(tib, type = 'add', sense_only = FALSE) {

  # validate args
  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  # define homo-/heterotypic class for pairs
  tib <- tib %>%
    mutate(same = ifelse(class %in% c('EE', 'PP'), 'Same', 'Different'))

  if(sense_only) {

    # filter out P in antisense orientation (in either position)
    tib <- tib %>%
      mutate(rm = (str_sub(id1, 1, 1) == 'P' & strand1 == '-') | (str_sub(id2, 1, 1) == 'P' & strand2 == '-')) %>%
      filter(rm == FALSE)

  }

  # define x-axis range
  if(type == 'add') {
    x_min <- round(quantile(tib[['coop_add']], na.rm = TRUE, probs = 1e-3))
    x_max <- round(quantile(tib[['coop_add']], na.rm = TRUE, probs = 1 - 1e-3))
  }
  else {
    x_min <- round(quantile(tib[['coop_hsa']], na.rm = TRUE, probs = 1e-3))
    x_max <- round(quantile(tib[['coop_hsa']], na.rm = TRUE, probs = 1 - 1e-3))
  }


  # set color palette
  pal <- c('orangered', 'orange', 'skyblue3', 'navyblue')

  if(type == 'add') {

    p <- tib %>%
      ggplot(aes(coop_add, fill = class)) +
      facet_wrap(~same) +
      labs(x = 'Cooperativity index (Additive)', y = 'Density', fill = '')
  }

  else {

    p <- tib %>%
      ggplot(aes(coop_hsa, fill = class)) +
      facet_wrap(~same) +
      labs(x = 'Cooperativity index (HSA)', y = 'Density', fill = '')
  }

  p +
    geom_density(size = 0.5, alpha = 0.5) +
    scale_fill_manual(values = pal) +
    coord_cartesian(xlim = c(x_min, x_max)) +
    geom_vline(xintercept = 0) +
    theme_bw() +
    theme(text = element_text(size = 15))

}


#' @title Plot cooperativity matrix (along with basal activity barplots)
#'
#' @usage plot_coop_heatmap(tib, tib_all, class = 'all', type = 'add', winsorize = FALSE, interactive = FALSE, skip_n_lab = 1)
#'
#' @param tib tibble, containing combinatorial elements (post-summarization with \link{add_metadata})
#' @param tib_all tibble, containing combinatorial elements (post-summarization with \link{add_metadata}) and including inactive pairs. This defines the matrix size.
#' @param class character, defining the type of the combinatorial class to be shown. Can be one of 'EE', 'EP', 'PE', 'PP' or 'all' for all classes. Default to 'all'.
#' @param type character, defines the cooperativity measure to be shown. Use 'add' for additive and 'hsa' for highest-single activity, respectively.
#' @param winsorize logical, if TRUE cooperativity values are mapped to the range [0.5, 99.5] percentile. Default to FALSE.
#' @param interactive logical, if TRUE an interactive visualization in returned. Default to FALSE. Useful to navigate mid-sized submatrices.
#' @param skip_n_lab integer, the spacing between axes labels. Default to 1.
#'
#' @return Called for its effect, returns a matrix plot with marginal barplots
#'
#' @note The interactive visualization is currently restricted to active pairs only.
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_heatmap
#'
#'
plot_coop_heatmap <- function(tib, tib_all, class = 'all', type = 'add', winsorize = FALSE, interactive = FALSE, skip_n_lab = 1) {

  # validate args
  if(!class %in% c('all', 'EE', 'EP', 'PE', 'PP'))
    stop('Undefined class type. Please use one of EE, EP, PE or PP, or leave default for all pairs')

  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  if(class != 'all') {
    # note: tib %>% filter(class == get('class')) fails
    # see https://stackoverflow.com/questions/40169949/filter-dataframe-using-global-variable-with-the-same-name-as-column-name

    tib     <- tib[tib[['class']] == class, ]
    tib_all <- tib_all[tib_all[['class']] == class, ]
  }

  # set color palette
  pal <- c('navyblue', 'gray95', 'orangered')

  # if winsorize, quantilize coop indices
  if(winsorize) {

    q1 <- quantile(tib[['coop_add']], p = 0.005, na.rm = TRUE)
    q2 <- quantile(tib[['coop_add']], p = 0.995, na.rm = TRUE)

    tib <- tib %>%
      mutate(coop_add = ifelse(coop_add < q1, q1, coop_add),
             coop_add = ifelse(coop_add > q2, q2, coop_add))

  }

  # static viz
  if(!interactive) {
    if(type == 'add') {

      # compute coop index range
      y_min <- min(tib[['coop_add']], na.rm = TRUE)
      y_max <- max(tib[['coop_add']], na.rm = TRUE)

      # coop index heatmap (additive)
      p_main <- tib_all %>%
        ggplot(aes(x = id1, y = id2)) +
        geom_tile(fill = 'gray40') +
        #        geom_tile(color = 'gray20', alpha = 0, size = 0.5) + ## prev version with stroke
        #        geom_tile(fill = rgb(53/255, 143/255, 168/255, 0.1)) + ## prev version with color outside coop idx palette
        geom_raster(data = tib, aes(x = id1, y = id2, fill = coop_add))

    }

    else {

      # compute coop index range
      y_min <- min(tib[['coop_hsa']], na.rm = TRUE)
      y_max <- max(tib[['coop_hsa']], na.rm = TRUE)

      # coop index heatmap (additive)
      p_main <- tib_all %>%
        ggplot(aes(x = id1, y = id2)) +
        geom_tile(fill = 'gray80') +
        #        geom_tile(color = 'gray20', alpha = 0, size = 0.5) + ## prev version with stroke
        #        geom_tile(fill = rgb(53/255, 143/255, 168/255, 0.1)) + ## prev version with color outside coop idx palette
        geom_raster(data = tib, aes(x = id1, y = id2, fill = coop_hsa))

    }

    # marginal barplots
    tib_p_top <- tib_all %>%
      select(id1, activity_all_frag1) %>%
      distinct() %>%
      mutate(activity_orig = log2(activity_all_frag1),
             shift    = min(activity_orig[!is.infinite(activity_orig)], na.rm = TRUE),
             activity = activity_orig + abs(shift))

    p_top <- tib_p_top %>%
      ggplot(aes(id1, activity)) +
      geom_bar(stat = 'identity') +
      scale_y_continuous(breaks = c(min(tib_p_top[['activity']][!is.infinite(tib_p_top[['activity']])]),
                                    max(tib_p_top[['activity']])),
                         labels = c(signif(min(tib_p_top[['activity_orig']][!is.infinite(tib_p_top[['activity_orig']])]), 2),
                                    signif(max(tib_p_top[['activity_orig']]), 2)))

    tib_p_right <- tib_all %>%
      select(id2, activity_all_frag2) %>%
      distinct() %>%
      mutate(activity_orig = log2(activity_all_frag2),
             shift    = min(activity_orig[!is.infinite(activity_orig)], na.rm = TRUE),
             activity = activity_orig + abs(shift))

    p_right <- tib_p_right %>%
      ggplot(aes(id2, activity)) +
      geom_bar(stat = 'identity') +
      scale_y_continuous(breaks = c(min(tib_p_right[['activity']][!is.infinite(tib_p_right[['activity']])]),
                                    max(tib_p_right[['activity']])),
                         labels = c(signif(min(tib_p_right[['activity_orig']][!is.infinite(tib_p_right[['activity_orig']])]), 2),
                                    signif(max(tib_p_right[['activity_orig']]), 2))) +
      coord_flip()

    # cosmetics
    p_main <- p_main +
      scale_fill_gradientn(colors = pal,
                           values = rescale(c(y_min, 0, y_max))) +
      labs(x = 'First element', y = 'Second element', fill = 'coop', caption = paste0('(n = ', nrow(tib), ' pairs)')) +
      theme(axis.text.x      = element_text(angle = 90, color =  c('black', rep('transparent', skip_n_lab))),
            axis.text.y      = element_text(color =  c('black', rep('transparent', skip_n_lab))),
            panel.grid       = element_blank(),
            panel.background = element_rect(fill = "white"),
            legend.position  = 'bottom',
            text             = element_text(size = 13))

    p_top <- p_top +
      labs(x = NULL,  y = 'Basal (log2)') +
      theme_bw() +
      theme(axis.line.x  = element_line(size = 0, colour = "white"),
            axis.ticks.x = element_line(size = 0),
            axis.text.x  = element_blank(),
            panel.border = element_blank(),
            panel.grid   = element_blank(),
            text         = element_text(size = 13))

    p_right <- p_right +
      labs(x = NULL,  y = 'Basal (log2)') +
      theme_bw() +
      theme(axis.line.y  = element_line(size = 0, colour = "white"),
            axis.ticks.y = element_line(size = 0),
            axis.text.y  = element_blank(),
            panel.border = element_blank(),
            panel.grid   = element_blank(),
            text         = element_text(size = 13))

    p_empty <- ggplot(mtcars, aes(wt, mpg)) +
      theme(line             = element_blank(),
            text             = element_blank(),
            title            = element_blank(),
            panel.background = element_rect(fill = NA, size = 0), plot.background = element_rect(size = 0))
    egg::ggarrange(p_top,
                   p_empty,
                   p_main,
                   p_right,
                   nrow = 2,
                   ncol = 2,
                   widths = c(3, 1),
                   heights = c(1, 3))

  }

  # interactive viz
  else {

    mat <- tib_to_mat(tib, var = ifelse(type == 'add', 'coop_add', 'coop_hsa'))

    heatmaply::heatmaply(mat,
                         Rowv = FALSE,
                         Colv = FALSE,
                         xlab = 'First element',
                         ylab = 'Second element',
                         showticklabels = c(TRUE, TRUE),
                         margins = c(100, 100, 40, 20),
                         scale_fill_gradient_fun = ggplot2::scale_fill_gradientn(colors = pal,
                                                                                 values = rescale(c(min(mat), 0, max(mat)))))
  }
}


#' @title Plot basal activity by element class and/or orientation
#'
#' @usage plot_basal_activity(tib, orient = FALSE)
#'
#' @param tib tibble, containing activity values for fragments in the basal library (this function is typically called with the output of \link{compute_cooperativity})
#' @param orient logical, if TRUE
#'
#' @return a boxplot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_basal_activity
#'
#'
plot_basal_activity <- function(tib, orient = FALSE) {

  if(orient) {

    # filter for fragments present in both orientation
    tib <- tib %>%
      group_by(frag) %>%
      summarize(n = n()) %>%
      filter(n == 2) %>%
      left_join(tib, by = 'frag')

    # count E and P
    tab <- table(tib[['class']])

    # boxplot
    tib %>%
      ggplot(aes(x = class, y = log2(activity_all), color = strand)) +
      geom_boxplot(size = 1) +
      labs(x = '', y = 'Basal activity (log2)', caption = paste0('E (n=', tab[['E']] / 2, '); P (n=', tab[['P']] / 2, ')')) +
      theme_bw() +
      theme(text = element_text(size = 15))
  }

  else {

    # boxplot
    tib %>%
      ggplot(aes(x = class, y = log2(activity_all), color = class)) +
      geom_boxplot(size = 1) +
      labs(x = '', y = 'Basal activity (log2)') +
      theme_bw() +
      theme(text = element_text(size = 15))
  }
}


#' @title Compare promoter activity in sense and antisense orientation
#'
#' @usage plot_promoter_directionality(tib)
#'
#' @param tib tibble, containing activity values for fragments in the basal library (this function is typically called with the output of \link{compute_cooperativity})
#'
#' @return a scatter plot (sense vs antisense activity) and promoter ranking by directionality index (sense/antisense activity)
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_promoter_directionality
#'
#'
plot_promoter_directionality <- function(tib) {

  # reshape tib: activity + vs -
  tib_filt <- tib %>%
    group_by(frag) %>%
    summarize(n = n()) %>%
    filter(n == 2) %>%
    left_join(tib, by = 'frag') %>%
    filter(class == 'P') %>%
    mutate(strand   = factor(strand),
           activity = log2(activity_all)) %>%
    dplyr::select(frag, strand, activity) %>%
    spread(strand, activity) %>%
    dplyr::rename(sense = `+`, antisense = `-`)

  # scatter plot
  p1 <- tib_filt %>%
    ggplot(aes(x = sense, y = antisense)) +
    geom_point() +
    labs(x = 'Sense activity (log2)', y = 'Antisense activity (log2)', caption = paste0('(n = ', nrow(tib_filt), ' P)')) +
    geom_abline(slope = 1, intercept = 0) +
    theme_bw() +
    theme(text = element_text(size = 15))

  # compute directionality index

  tib_di <- tib_filt %>%
    mutate(di = 2 ^ (sense - antisense)) %>%
    arrange(desc(di))

  p2 <- tib_di %>%
    ggplot(aes(x = factor(frag, levels = frag, ordered = TRUE), y = di)) +
    geom_point(size = 1) +
    labs(x = '', y = 'Directionality index (sense/antisense)', caption = paste0('(n = ', nrow(tib_di), ' P)')) +
    geom_hline(yintercept = 1) +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 90),
          text = element_text(size = 15))

  grid.arrange(p1, p2)
}


#' @title Plot combinatorial activity by class
#'
#' @usage plot_activity_by_class(tib, signal_t, percent = FALSE)
#'
#' @param tib tibble, containing activity values for fragments in the combinatorial library (this function is typically called with the output of \link{compute_cooperativity})
#' @param signal_t numeric, the activity signal threshold as returned by \link{learn_min_activity}
#' @param percent logical, if TRUE the percentage of elements in each class is shown. Default to FALSE (frequency)
#'
#' @return a barplot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_activity_by_class
#'
#'
plot_activity_by_class <- function(tib, signal_t, percent = FALSE) {

  if(!percent) {

    tib %>%
      group_by(class) %>%
      summarize(n        = n(),
                active   = sum(activity_all >= signal_t),
                inactive = n - active) %>%
      dplyr::select(-n) %>%
      melt() %>%
      ggplot(aes(x = class, y = value, fill = variable)) +
      geom_bar(stat =  'identity') +
      labs(x = '', y = 'Number of pairs', fill = '') +
      theme_bw() +
      theme(text = element_text(size = 15))
  }

  else {

    tib %>%
      group_by(class) %>%
      summarize(n    = n(),
                active   = sum(activity_all >= signal_t) / n * 100,
                inactive = 100 - active) %>%
      dplyr::select(-n) %>%
      melt() %>%
      ggplot(aes(x = class, y = value, fill = variable)) +
      geom_bar(stat =  'identity') +
      labs(x = '', y = 'Percentage of pairs', fill = '') +
      theme_bw() +
      theme(text = element_text(size = 15))
  }
}


#' @title Plot cooperativity profiles
#'
#' @usage plot_coop_profile(tib, class = 'EP', type = 'add')
#'
#' @param tib tibble, containing cooperativity values for fragments in the combinatorial library (see \link{compute_cooperativity})
#' @param class character, specifies the class of pairs of interest. One of 'EP', 'EE', 'PE' or 'PP'. All classes are considered by default
#' @param type character, either 'add' for supra-additive cooperativity or 'hsa' for highest-single activity cooperativity
#'
#' @return A histogram of cooperativity profiles for elements in second position within a pair, for which both sense and antisense orientations are present in the combinatorial library.
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_profile
#'
#'
plot_coop_profile <- function(tib, class = 'EP', type = 'add') {

  # validate args
  if(!class %in% c('EE', 'EP', 'PE', 'PP'))
    stop('Undefined class type. Please use one of EE, EP, PE or PP.')

  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  tib <- tib %>%
    # create query
    group_by(frag2) %>%
    summarize(n = n_distinct(strand2)) %>%
    filter(n == 2) %>%
    # merge back
    left_join(tib, by = 'frag2')

  # note: tib %>% filter(class == get('class')) fails
  # see https://stackoverflow.com/questions/40169949/filter-dataframe-using-global-variable-with-the-same-name-as-column-name
  tib <- tib[tib[['class']] == class, ]

  if(type == 'add') {

    p <- tib %>%
      dplyr::select(frag2, strand2, class, coop_add) %>%
      ggplot(aes(x = coop_add, fill = strand2))
  }

  else {

    p <- tib %>%
      dplyr::select(frag2, strand2, class, coop_hsa) %>%
      ggplot(aes(x = coop_hsa, fill = strand2))
  }

  p +
    facet_wrap(~frag2) +
    geom_histogram(alpha = 0.7) +
    scale_fill_manual(values = c('orangered', 'skyblue3')) +
    geom_vline(xintercept = 0) +
    labs(x = 'Cooperativity index', y = 'Frequency', fill = 'Orient', caption = paste0('(n = ', nrow(tib), ' pairs)')) +
    theme_bw() +
    theme(text = element_text(size = 15))

}


#' @title Plot positional basal activity ratio by class
#'
#' @usage plot_position_effect(tib, ...)
#'
#' @param tib tibble, containing activity values for fragments in the combinatorial library (this function is typically called with the output of \link{compute_cooperativity})
#' @param ... additional parameters to be passed to the `labs` function (add caption/title to plot)
#'
#' @return A histogram of the ratio between barcode-proximal and -distal element activities, for each class of pairs
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_position_effect
#'
#'
plot_position_effect <- function(tib, ...) {

  tib %>%
    # compute activity ratio (pos2/pos1)
    mutate(r = log2(activity_all_frag2 / activity_all_frag1)) %>%
    ggplot(aes(r, fill = class)) +
    geom_histogram() +
    facet_wrap(~class) +
    labs(x = 'Activity ratio (position 2 / position 1, log2)', y = 'Count', fill = 'Class', ...) +
    geom_vline(xintercept = 0) +
    theme_bw() +
    theme(text = element_text(size = 15))
}


#' @title Pairs plot of activity (compare replicates)
#'
#' @usage pairs_plot_activity(tib, min_offset = 1e-3, alpha = 0.5, ...)
#'
#' @param tib tibble, containing activity values for fragments in the basal or combinatorial library (see \link{compute_cooperativity})
#' @param min_offset numeric, the offset to added prior to log transformation (e.g. the minimum a 1st percentile of activity values)
#' @param alpha numeric, the transparency level to be passed to `geom_point`
#' @param ... additional parameters to be passed to `ggally_text`
#'
#' @return a pairs plot (scatter), which also includes the geometric mean of the activity values
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export pairs_plot_activity
#'
#'
pairs_plot_activity <- function(tib, min_offset = 1e-3, alpha = 0.5, ...) {

  # ggpairs custom functions
  corColor <- function(data, mapping, color = I("black"), sizeRange = c(1, 3), ...) {

    x   <- eval_data_col(data, mapping$x)
    y   <- eval_data_col(data, mapping$y)
    r   <- cor(x, y)
    rt  <- format(r, digits = 3)
    tt  <- as.character(rt)
    cex <- max(sizeRange)

    # helper function to calculate a useable size
    percent_of_range <- function(percent, range) {
      percent * diff(range) + min(range, na.rm = TRUE)
    }

    # plot correlation coefficient
    p <- ggally_text(label = tt, mapping = aes(), xP = 0.5, yP = 0.5,
                     size = I(percent_of_range(cex * abs(r), sizeRange)), color = color, ...) +
      theme(panel.grid.minor=element_blank(),
            panel.grid.major=element_blank())

    corColors <- RColorBrewer::brewer.pal(n = 7, name = "RdYlBu")[2:6]

    if (r <= -0.8) {
      corCol <- corColors[1]
    } else if (r <= -0.6) {
      corCol <- corColors[2]
    } else if (r < 0.6) {
      corCol <- corColors[3]
    } else if (r < 0.8) {
      corCol <- corColors[4]
    } else {
      corCol <- corColors[5]
    }

    p <- p +
      theme(panel.background = element_rect(fill = corCol))

    return(p)
  }

  smoothPanel <- function(data, mapping, ...) {
    ggplot(data = data, mapping = mapping) +
      geom_point(aes(color = I("black")), alpha = alpha) +
      scale_color_manual(values = 'skyblue3') +
#      geom_smooth(method = "lm", color = I('orangered')) +
      geom_abline(slope = 1, intercept = 0, color = 'gray50', linetype = 'dotted', size = 1) +
      theme(panel.background=element_blank(),
            panel.grid.minor=element_blank(),
            panel.grid.major=element_line(color="gray"))
  }

  tib %>%
    select(starts_with('activity'), -contains('frag')) %>%
    mutate_all(funs(log10(. + min_offset))) %>%
    ggpairs(
      upper  = list(continuous = corColor),
      diag   = list(continuous = 'densityDiag'),
      lower  = list(continuous = smoothPanel)) +
    #axisLabels = 'none') +
    labs(caption = 'Based on log10 activity values')

}



#' @title Pairs plot of cooperativity indices (compare replicates)
#'
#' @usage pairs_plot_coop(tib, alpha, ...)
#'
#' @param tib tibble, containing cooperativity indices (see \link{compute_cooperativity})
#' @param alpha numeric, the transparency level to be passed to `geom_point`
#' @param ... additional parameters to be passed to `ggally_text`
#'
#' @return a pairs plot (scatter), which also includes the geometric mean of the cooperativity indices
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export pairs_plot_coop
#'
#'
pairs_plot_coop <- function(tib, alpha, ...) {

  # ggpairs custom functions
  corColor <- function(data, mapping, color = I("black"), sizeRange = c(1, 3), ...) {

    x   <- eval_data_col(data, mapping$x)
    y   <- eval_data_col(data, mapping$y)
    r   <- cor(x, y)
    rt  <- format(r, digits = 3)
    tt  <- as.character(rt)
    cex <- max(sizeRange)

    # helper function to calculate a useable size
    percent_of_range <- function(percent, range) {
      percent * diff(range) + min(range, na.rm = TRUE)
    }

    # plot correlation coefficient
    p <- ggally_text(label = tt, mapping = aes(), xP = 0.5, yP = 0.5,
                     size = I(percent_of_range(cex * abs(r), sizeRange)), color = color, ...) +
      theme(panel.grid.minor=element_blank(),
            panel.grid.major=element_blank())

    corColors <- RColorBrewer::brewer.pal(n = 7, name = "RdYlBu")[2:6]

    if (r <= -0.8) {
      corCol <- corColors[1]
    } else if (r <= -0.6) {
      corCol <- corColors[2]
    } else if (r < 0.6) {
      corCol <- corColors[3]
    } else if (r < 0.8) {
      corCol <- corColors[4]
    } else {
      corCol <- corColors[5]
    }

    p <- p +
      theme(panel.background = element_rect(fill = corCol))

    return(p)
  }

  smoothPanel <- function(data, mapping, ...) {
    ggplot(data = data, mapping = mapping) +
      geom_point(aes(color = I("black")), alpha = alpha) +
      scale_color_manual(values = 'skyblue3') +
#      geom_smooth(method = "lm", color = I('orangered')) +
      geom_abline(slope = 1, intercept = 0, color = 'gray50', linetype = 'dotted', size = 1) +
      theme(panel.background=element_blank(),
            panel.grid.minor=element_blank(),
            panel.grid.major=element_line(color="gray"))
  }

  tib %>%
    select(starts_with('coop')) %>%
    ggpairs(
      upper  = list(continuous = corColor),
      diag   = list(continuous = 'densityDiag'),
      lower  = list(continuous = smoothPanel)) +
    #axisLabels = 'none') +
    labs(caption = 'Based on additive cooperativity index')

}


#' @title Plot cooperativity index as a function of the endogenous genomic distance between elements of a pair
#'
#' @usage plot_coop_distance(tib, byclass = FALSE, type = 'add')
#'
#' @param tib tibble, containing cooperativity values for fragments in the combinatorial library (see \link{compute_cooperativity})
#' @param byclass logical, if TRUE, a plot is returned for each class of pairs (e.g. EP, EE pairs)
#' @param type character, either 'add' for supra-additive cooperativity or 'hsa' for highest-single activity cooperativity. Default to 'add'
#'
#' @return A scatter plot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_distance
#'
#'
plot_coop_distance <- function(tib, byclass = FALSE, type = 'add') {

  # validate args
  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  if(type == 'add') {
    tib <- tib %>%
      rename(coop = coop_add) }
  else {
    tib <- tib %>%
      rename(coop = coop_hsa)
  }

  # plot coop vs distance
  p <- tib %>%
    mutate(log_dist = log10(dist)) %>%
    ggplot(aes(log_dist, coop, fill = class)) +
    geom_point(alpha = 0.2) +
    geom_smooth() +
    geom_hline(yintercept = 0, linetype = 'dotted') +
    coord_cartesian(xlim = c(3, 6)) +
    labs(x = 'Genomic distance (log10)', y = 'Cooperativity index') +
    theme_bw()

  if(byclass) {
    p <- p +
      facet_wrap(~class)
  }

  p
}


#' @title Plot cooperativity as a function of the basal activity of the barcode-proximal element of a pair
#'
#' @usage plot_coop_by_basal(tib, class = 'EP', type = 'add')
#'
#' @param tib tibble, containing cooperativity values for fragments in the combinatorial library (see \link{compute_cooperativity})
#' @param class character, specifies the class of pairs of interest. One of 'EP', 'EE', 'PE' or 'PP'.
#' @param type character, either 'add' for supra-additive cooperativity or 'hsa' for highest-single activity cooperativity
#'
#' @return A boxplot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_by_basal
#'
#'
plot_coop_by_basal <- function(tib, class = 'EP', type = 'add') {

  # validate args
  if(!class %in% c('EE', 'EP', 'PE', 'PP'))
    stop('Undefined class type. Please use one of EE, EP, PE or PP.')

  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  # note: tib %>% filter(class == get('class')) fails
  # see https://stackoverflow.com/questions/40169949/filter-dataframe-using-global-variable-with-the-same-name-as-column-name
  tib <- tib[tib[['class']] == class, ]

  if(type == 'add') {
    tib <- tib %>%
      rename(coop = coop_add) }
  else {
    tib <- tib %>%
      rename(coop = coop_hsa)
  }

  # count number of distinct element 2 for color palette
  n_elements <- tib[['id2']] %>%
    unique %>%
    length

  tib %>%
    arrange(desc(activity_all_frag2)) %>%
    mutate(id2 = factor(id2, levels = unique(id2))) %>%
    ggplot(aes(x = log2(activity_all_frag2), y = coop)) +
      geom_point(aes(color = id2), alpha = 0.35) +
      geom_boxplot(aes(group = id2, color = id2), outlier.shape = NA) +
      scale_color_manual(values = rev(wes_palette('Zissou1', n_elements, type = 'continuous'))) +
      geom_hline(yintercept = 0, linetype = 'dotted') +
      labs(x = 'Basal activity (element 2, log2)', y = 'Cooperativity index') +
      theme_bw() +
      theme(axis.title   = element_text(size = 13),
            axis.text    = element_text(size = 12),
            legend.title = element_text(size = 0))

}


#' @title Plot ranking of barcode-proximal elements in a pair by promiscuity index
#'
#' @usage plot_promiscuity_ranking(tib, class = 'EP', type = 'add', coop_threshold = 0)
#'
#' @param tib tibble, containing cooperativity values for fragments in the combinatorial library (see \link{compute_cooperativity})
#' @param class character, specifies the class of pairs of interest. One of 'EP', 'EE', 'PE' or 'PP'.
#' @param type character, either 'add' for supra-additive cooperativity or 'hsa' for highest-single activity cooperativity. Default to 'add'
#' @param coop_threshold numeric, the cooperativity threshold to be used for defining cooperative pairs.
#'
#' @return A scatter plot with point size proportional to the number of active pairs, color-coded according to the basal activity of the second element in the pair. If a promoter is in second position, only pairs with the promoter in sense orientation are considered
#'
#' @note The promiscuity index is defined as the fraction of cooperative pairs among all active pairs for a given barcode-proximal element in a pair
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_promiscuity_ranking
#'
#'
plot_promiscuity_ranking <- function(tib, class = 'EP', type = 'add', coop_threshold = 0) {

  # validate args
  if(!class %in% c('EE', 'EP', 'PE', 'PP'))
    stop('Undefined class type. Please use one of EE, EP, PE or PP.')

  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  if(coop_threshold < 0)
    warning('Negative cooperativity threshold provided as input')

  # note: tib %>% filter(class == get('class')) fails
  # see https://stackoverflow.com/questions/40169949/filter-dataframe-using-global-variable-with-the-same-name-as-column-name
  tib <- tib[tib[['class']] == class, ]

  # if promoter, keep sense orientation only
  if(str_sub(class, 2, 2) == 'P') {
    tib <- tib %>%
      filter(strand2 == '+')
  }

  # select cooperativity type
  if(type == 'add') {
    tib <- tib %>%
      rename(coop = coop_add) }
  else {
    tib <- tib %>%
      rename(coop = coop_hsa)
  }

  tib %>%
    group_by(id2, activity_all_frag2) %>%
    summarise(n_active  = sum(active),
              n_coop    = sum(active & coop > coop_threshold, na.rm = TRUE)) %>%
    ungroup() %>%
    mutate(promiscuity = n_coop / n_active) %>%
    # rank desc by promiscuity
    arrange(desc(promiscuity)) %>%
    mutate(id2 = factor(id2, levels = unique(id2))) %>%
    ggplot(aes(x = id2, y = promiscuity, size = n_active, color = log2(activity_all_frag2))) +
    geom_point() +
    geom_hline(yintercept = 0.5, linetype = 'dotted') +
    labs(x = NULL, y = 'Promiscuity (#coop / #active)', color = 'Basal (log2)', size = '#active', caption = paste0('Min cooperativity threshold: ', coop_threshold)) +
    theme_bw() +
    theme(axis.text.x  = element_text(angle = 90),
          axis.title   = element_text(size = 14),
          axis.text    = element_text(size = 12),
          legend.text  = element_text(size = 10),
          plot.caption = element_text(size = 12),
          legend.title = element_text(size = 12))

}


#' @title Plot cooperativity vs boost index
#'
#' @usage plot_coop_vs_boost(tib, type = 'add')
#'
#' @param tib tibble, containing cooperativity values for fragments in the combinatorial library (see \link{compute_cooperativity})
#' @param type character, either 'add' for supra-additive cooperativity or 'hsa' for highest-single activity cooperativity. Default to 'add'
#'
#' @return A scatter plot
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_vs_boost
#'
#'
plot_coop_vs_boost <- function(tib, type = 'add') {

  if(!type %in% c('add', 'hsa'))
    stop('Undefined cooperativity index type. Please use either add or hsa')

  # select cooperativity type
  if(type == 'add') {
    tib <- tib %>%
      rename(coop = coop_add) }
  else {
    tib <- tib %>%
      rename(coop = coop_hsa)
  }

  tib %>%
    ggplot(aes(x = boost, y = coop)) +
    geom_point(alpha = 0.2) +
    facet_wrap(~class) +
    labs(x = 'Boost index (log2)', y = 'Cooperativity index (log2)') +
    theme_bw() +
    theme(axis.text = element_text(size = 12))

}


#' @title Plot basal activity vs X-seq (e.g. ChIP-seq, DNase-seq) signal
#'
#' @usage plot_activity_vs_xseq_signal(tib, bam_fn, width = NULL, overlapping = TRUE, paired_end = FALSE, map_qual = 20, frag_len = 0, strand = 'both', title)
#'
#' @param tib tibble, containing basal or combinatorial library fragments (post-summarization with \link{add_metadata})
#' @param bam_fn character, (full) path to BAM file. This must be indexed, i.e. a .bai file must be located in the same directory
#' @param width integer, if specified, query genomic regions will be resized to width
#' @param overlapping logical, if FALSE overlapping ranges in the query will be discarded. Default to TRUE.
#' @param paired_end logical, if TRUE the BAM file contains paired-end reads and only the 5' position of the first read in a proper mapped pair will be considered (SAM flag 66). Default to FALSE (i.e. single end).
#' @param map_qual integer, minimum read mapping quality. Default to 20.
#' @param frag_len integer, the approximate average fragment length. Default to 0, i.e. no shift of 5' read position is performed.
#' @param strand character, the count mode. One of 'sense', 'antisense' or 'both'. Default to 'both', i.e. the sum of sense and antisense counts is returned.
#' @param rpm logical, if TRUE, reads per million are returned instead of raw counts. Library sizes are computed internally.
#' @param title character, the plot title
#'
#' @return Called for its effects
#'
#' @note This function is based on \link{get_signal_bam}
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_activity_vs_xseq_signal
#'
#'
plot_activity_vs_xseq_signal <- function(tib, bam_fn, width = NULL, overlapping = TRUE, paired_end = FALSE, map_qual = 20, frag_len = 0, strand = 'both', rpm = FALSE, title) {

  query_gr <- tib_to_gr(tib)
  sgnl     <- get_signal_bam(query_gr, bam_fn, width, overlapping, paired_end, map_qual, frag_len, strand, rpm)

  # add signal to tibble
  tib[['sgn']] <- sgnl

  # if raw counts, add pseudocount = 1
  if(!rpm) {
    tib %>%
      mutate(sgnl = 1 + sgnl)
  }

  tib %>%
    ggplot(aes(x = log2(activity_all), y = log2(sgnl), color = class)) +
    geom_point() +
    ggpubr::stat_cor(method = 'pearson', label.x.npc = 0.5, label.y.npc = 0.1, size = 4, show.legend = FALSE) +
    labs(x = 'Basal activity (log2)', y = 'Signal (log2)', title = title) +
    theme_bw() +
    theme(text         = element_text(size = 12),
          axis.title   = element_text(size = 12),
          axis.text    = element_text(size = 12),
          legend.text  = element_text(size = 12),
          legend.title = element_blank())

}


#' @title Plot cooperativity values by presence/absence of 3D interaction in Capture Hi-C (boxplot)
#'
#' @usage plot_coop_by_chic(tib, mode = 'binary', min_chic_score = 5, cutoff_vec = c(5), ...)
#'
#' @param tib tibble, containing basal or combinatorial library fragments (post-annotation with \link{get_interacting_pairs})
#' @param mode logical, if 'binary' pairs are partitioned in interacting/non-interacting groups based on the supplied min_chic_score. If 'multi', pairs are partitioned in multiple interaction groups of increasing significance level, according to the cutoff scores supplied in the cutoff_vec vector
#' @param min_chic_score integer, the minimum CHiCAGO score (encoded as -log10(p-val)) to be considered significant. Default to 5.
#' @param cutoff_vec integer vector, the set of CHiCAGO score (encoded as -log10(p-val)) to be used to partition interacting pairs into multiple interaction groups of increasing significance level. Default to c(5).
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Called for its effects
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_by_chic
#'
#'
plot_coop_by_chic <- function(tib, mode = 'binary', min_chic_score = 5, cutoff_vec = c(5), ...) {

  # validate args
  if(!mode %in% c('binary', 'multi')) {
    stop('Invalid mode. Please use one of binary or quantile.')
  }

  # if mode is binary, threshold scores based on min_chic_score
  if(mode == 'binary') {
    tib <- tib %>%
      mutate(contact = chic_score >= min_chic_score)
  }
  # if mode is multi, split scores in groups based on cutoff_vec
  else {
    tib <- tib %>%
      mutate(contact = cut(chic_score, breaks  = unique(c(0, cutoff_vec, max(chic_score))), include.lowest = TRUE))
  }

  # define size of groups
  group_size <- tib %>%
    group_by(contact) %>%
    summarize(n = n()) %>%
    dplyr::select(n) %>%
    unlist

  # boxplot/violin plot
  tib %>%
    ggplot(aes(x = contact, y = coop_add)) +
    geom_violin(aes(fill = contact)) +
    geom_boxplot(width = 0.1) +
    {if(mode == 'binary')
      ggsignif::geom_signif(comparisons      = list(c('TRUE', 'FALSE')),
                            test             = 'wilcox.test',
                            map_signif_level = FALSE)
      else
        ggsignif::geom_signif(comparisons      = expand.grid(1, 2 : length(unique(tib[['contact']]))) %>% apply(1, list) %>% unlist(recursive = FALSE),
                              test             = 'wilcox.test',
                              step_increase = 0.05,
                              map_signif_level = FALSE)} +
    labs(x = ifelse(mode =='binary', '3D contact', 'CHi-C score'), y = 'Cooperativity', caption = paste0('N = (', paste(group_size, collapse = ' ,'), ')'), ...) +
    theme_bw()

}


#' @title Plot cooperativity values for intra- and inter-TAD pairs
#'
#' @usage plot_coop_by_tad_localization(tib, ...)
#'
#' @param tib tibble, containing combinatorial library fragments (post-annotation with \link{get_interacting_pairs})
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Called for its effects
#'
#' @note This function also compares the cooperativity distribution of intra-TAD pairs to a "distance-matched" inter-TAD sample. This is currently obtained empirically (based on the 70-th percentile of the distance distribution for intra-TAD pairs)
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_by_tad_localization
#'
#'
plot_coop_by_tad_localization <- function(tib, ...) {

  # define intra, inter, and distance matched inter pairs
  tib_intra <- tib %>%
    filter(intra_tad == TRUE) %>%
    mutate(type = 'intra')
  tib_inter <- tib %>%
    filter(intra_tad == FALSE) %>%
    mutate(type = 'inter')

  # compute 70% q of intra-TAD genomic distances
  q_dist <- quantile(tib_intra[['dist']], p = 0.7)

  # select distance-matched set from inter-TAD pairs
  tib_inter_dm <- tib_inter %>%
    filter(dist <= q_dist) %>%
    mutate(type = 'inter_dm')

  tib <- bind_rows(tib_intra, tib_inter, tib_inter_dm)

  # define color palette
  col_pal <- c('gray70', 'gray40', 'steelblue')

  # boxplot/violin plot (cooperativity)
  p_top_left <- tib %>%
    ggplot(aes(x = type, y = coop_add)) +
    geom_violin(aes(fill = type)) +
    geom_boxplot(width = 0.1) +
    scale_fill_manual(values = col_pal) +
    ggsignif::geom_signif(comparisons      = list(c('inter', 'intra'), c('inter_dm', 'intra')),
                          test             = 'wilcox.test',
                          map_signif_level = FALSE,
                          step_increase    = 0.1) +
    labs(x = 'TAD localization', y = 'Cooperativity') +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 90, hjust = 1),
          legend.position = 'none')

  # boxplot/violin plot (genomic distance)
  p_top_right <- tib %>%
    ggplot(aes(x = type, y = log10(1 + dist))) +
    geom_violin(aes(fill = type)) +
    scale_fill_manual(values = col_pal) +
    geom_boxplot(width = 0.1) +
    labs(x = 'TAD localization', y = 'Genomic distance (log10)') +
    theme_bw() +
    theme(axis.text.x = element_text(angle = 90, hjust = 1),
          legend.position = 'none')

  # scatter coop vs distance + fit
  p_bottom <- tib %>%
    filter(type %in% c('intra', 'inter_dm')) %>%
    ggplot(aes(x = log10(1 + dist), y = coop_add, color = type)) +
    geom_point(alpha = 0.25) +
    geom_smooth(span = 0.8) +
    geom_hline(yintercept = 0, linetype = 'dotted') +
    scale_color_manual(values = col_pal[c(2,3)]) +
    labs(x = 'Genomic distance (log10)', y = 'Cooperativity', ...) +
    facet_wrap(~type, nrow = 2) +
    coord_cartesian(xlim = c(3, log10(1 + q_dist))) +
    theme_bw()

  # arrange plots in panels
  egg::ggarrange(p_top_left,
                 p_top_right,
                 p_bottom,
                 nrow = 1,
                 ncol = 3,
                 widths = c(2, 1, 3))
}


#' @title Plot cooperativity values by grouping pairs based on the occurrence of a given TF motif within each element
#'
#' @usage plot_coop_by_motif(tib, tf_id, type = 'violin', ...)
#'
#' @param tib_comb tibble, containing combinatorial library fragments and motif scores (as returned by \link{add_motif_score})
#' @param tf_id character, a TF identifiers. This should match the prefix of the two motif score columns of interest in tib_comb.
#' @param type character, 'violin' returns a violin plot, 'beeswarm' returns a beeswarm plot
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Called for its effects, returns a violin plot or a beeswarm plot
#'
#' @note Pairs are grouped into 3 classes: null, single hit, double hit pairs. See \link{screen_tf} for more details
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_by_motif
#'
#'
plot_coop_by_motif <- function(tib, tf_id, type = 'violin', ...) {

  # validate args
  if(!type %in% c('violin', 'beeswarm'))
    stop('Plot type should be one of violin, beeswarm')

  # generate colnames to match
  tf_id1 <- paste0(tf_id, '_frag1')
  tf_id2 <- paste0(tf_id, '_frag2')

  # create a symb
  col1 <- rlang::sym(tf_id1)
  col2 <- rlang::sym(tf_id2)

  # extract cols and count instances (!! to unquote symb)
  tib_plt <- tib %>%
    rowwise() %>%
    mutate(n = sum((!!col1) > 0, (!!col2) > 0),
           n = factor(n)) %>%
    dplyr::select(n, coop_add)

  # plot
  if(type == 'violin') {

    p <- tib_plt %>%
      ggplot(aes(x = n, y = coop_add)) +
      geom_violin(aes(fill = n)) +
      geom_boxplot(width = 0.1)

  }

  else {

    p <- tib_plt %>%
      ggplot(aes(x = n, y = coop_add)) +
      geom_boxplot(width = 0.3) +
      ggbeeswarm::geom_beeswarm(aes(color = n), alpha = 0.5)

  }

  # significance and labels
  p + ggsignif::geom_signif(comparisons      = list(c(1, 2), c(2, 3)),
                            test             = 'wilcox.test',
                            map_signif_level = FALSE,
                            step_increase    = 0.1) +
    labs(x = '#elements with motif', y = 'Cooperativity', ...) +
    theme_bw() +
    theme(legend.position = 'none')
}


#' @title Volcano plot of TF screen results
#'
#' @usage plot_tf_screen(tib, type, expr_cutoff = 0, qval = 1e-3, n_label = 20, ...)
#'
#' @param tib tibble, containing TF screening results (as returned by \link{screen_tf})
#' @param type character, if 'broad' one-hit pairs are compared to null pairs, if 'self' two-hit pairs are compared to one-hit pairs
#' @param expr_cutoff numeric, the expression cutoff to be used for filtering the screening results. Only TFs with expression >= expr_cutoff will be shown
#' @param qval numeric, the q-value (FDR) threshold to be used for calling significant hits. Default to 1e-3.
#' @param n_label integer, the number of top hits to be labeled. Default to 20.
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Called for its effects, returns a volcano plot
#'
#' @note See \link{screen_tf} for more details
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_tf_screen
#'
#'
plot_tf_screen <- function(tib, type, expr_cutoff = 0, qval = 1e-3, n_label = 20, ...) {

  # validate args
  if(!type %in% c('broad', 'self'))
    stop('Type can only be broad (one-hit vs null pairs) or self (two-hits vs one-hit)')

  # extract condition according to type and expression cutoff
  # note: if NA expression, retain TF
  tib <- tib[tib[['type']] == type & (tib[['expr_mean']] >= expr_cutoff | is.na(tib[['expr_mean']])), ]

  # log transform fdr
  tib <- tib %>%
    mutate(fdr = -log10(fdr))
  qval <- -log10(qval)

  # extract significant hits
  tib_signif <- tib %>%
    filter(fdr >= qval) %>%
    mutate(effect = ifelse(effect_size > 0, 'Pos', 'Neg'))

  # extract hits to label
  tib_lab <- tib_signif %>%
    arrange(desc(fdr)) %>%
    dplyr::slice(1 : n_label)

  tib %>%
    ggplot(aes(x = effect_size, y = fdr, label = id)) +
    geom_point(aes(size = n_min), alpha = 0.35) +
    geom_point(data = tib_signif, aes(x = effect_size, y = fdr, color = effect, size = n_min), alpha = 0.5) +
    ggrepel::geom_text_repel(data = tib_lab) +
    scale_color_manual(values = c('navyblue', 'orangered'), guide = FALSE) +
    geom_hline(yintercept = qval, linetype = 'dotted') +
    labs(x = expression(paste('Effect size (', Delta, 'median coop)')),
         y = '-log10(FDR)',
         size = 'min(#Pairs)', ...) +
    theme_bw() +
    theme(axis.title      = element_text(size = 14),
          axis.text       = element_text(size = 12))

}


#' @title Radial heatmap plot of TF screen results
#'
#' @usage plot_tf_screen_radial(tib, expr_cutoff = 0, qval = 1e-3, ...)
#'
#' @param tib tibble, containing TF screening results (as returned by \link{screen_tf})
#' @param expr_cutoff numeric, the expression cutoff to be used for filtering the screening results. Only TFs with expression >= expr_cutoff will be shown
#' @param qval numeric, the q-value cutoff to be used for selecting top hits. Default to 1e-3.
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Called for its effects, returns a radial heatmap. Inner heatmap: broad compatibility; Outer heatmap: self-compatibility
#'
#' @note See \link{screen_tf} for more details
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_tf_screen_radial
#'
#'
plot_tf_screen_radial <- function(tib, expr_cutoff = 0, qval = 1e-3, ...) {

  # select TF significantly broad or self compatible
  tib <- tib %>%
    semi_join(filter(tib, fdr <= qval, expr_mean >= expr_cutoff), by = 'id') %>%
    mutate(effect_size = ifelse(fdr <= qval, effect_size, NA))

  # count number of hits
  n <- tib %>%
    nrow

  # set color palette
  pal <- c('navyblue', 'gray95', 'orangered')

  # plot radial heatmap
  tib %>%
    # add an integer to numeric conversion of broad/self factor --> toroidal shape
    mutate(type = 5 + as.numeric(type)) %>%
    ggplot(aes(x = id, y = type, fill = effect_size)) +
    geom_tile(colour = 'white') +
    scale_fill_gradient2(low      = pal[1],
                         mid      = pal[2],
                         high     = pal[3],
                         midpoint = 0) +
    coord_polar(theta = 'x') +
    # hardcoded ylim: integer (5) + #classes (2) + 1
    ylim(c(0, 8)) +
    geom_text(aes(x = id, y = 8, label = id),
              # note: seq of length n/2 repeated twice (because of 2 classes)
              angle = 360 / (2 * pi) * rev(pi / 2 + rep(seq(pi / n, 2 * pi - pi / n, length = n / 2), 2)),
              hjust = 0) +
    labs(x = '', y = '', ...) +
    theme_bw() +
    theme(panel.border     = element_blank(),
          axis.text.x      = element_blank(),
          axis.text.y      = element_blank(),
          axis.ticks.y     = element_line(linetype = 'blank'),
          panel.grid.major = element_blank())
}


#' @title Volcano plot of heterotypic TF screen results
#'
#' @usage plot_heterotypic_tf_screen(tib, qval = 1e-3, n_label = 20, ...)
#'
#' @param tib tibble, containing TF screening results (as returned by \link{screen_heterotypic_tf})
#' @param qval numeric, the q-value (FDR) threshold to be used for calling significant hits. Default to 1e-3.
#' @param n_label integer, the number of top hits to be labeled. Default to 20.
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Called for its effects, returns a volcano plot
#'
#' @note See \link{screen_heterotypic_tf} for more details.
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_heterotypic_tf_screen
#'
#'
plot_heterotypic_tf_screen <- function(tib, qval = 1e-3, n_label = 20, ...) {

  # log transform fdr
  tib <- tib %>%
    mutate(fdr = -log10(pval_one))
  qval <- -log10(qval)

  # extract significant hits
  tib_signif <- tib %>%
    filter(fdr >= qval) %>%
    mutate(effect = ifelse(es_one > 0, 'Pos', 'Neg'))

  # extract hits to label
  tib_lab <- tib_signif %>%
    arrange(desc(fdr)) %>%
    dplyr::slice(1 : n_label)

  tib %>%
    ggplot(aes(x = es_one, y = fdr, label = tf_pair)) +
    geom_point(aes(size = n_one), alpha = 0.1) +
    geom_point(data = tib_signif, aes(x = es_one, y = fdr, color = effect, size = n_one), alpha = 0.5) +
    ggrepel::geom_text_repel(data = tib_lab) +
    scale_color_manual(values = c('navyblue', 'orangered'), guide = FALSE) +
    geom_hline(yintercept = qval, linetype = 'dotted') +
    labs(x = expression(paste('Effect size (', Delta, 'median coop)')),
         y = '-log10(FDR)',
         size = 'min(#Pairs)', ...) +
    theme_bw() +
    theme(axis.title      = element_text(size = 14),
          axis.text       = element_text(size = 12))

}


#' @title Plot cooperativity values by grouping pairs based on the occurrence of a given TF motif pair within each element
#'
#' @usage plot_coop_by_heterotypic_motif(tib_comb, tf1_id, tf2_id, type = 'violin', ...)
#'
#' @param tib_comb tibble, containing combinatorial library fragments and motif scores (as returned by \link{add_motif_score})
#' @param tf1_id character, the first TF identifier of the TF pair. This should match the prefix of the two motif score columns of interest in tib_comb.
#' @param tf2_id character, the second TF identifier of the TF pair. This should match the prefix of the two motif score columns of interest in tib_comb.
#' @param type character, 'violin' returns a violin plot, 'beeswarm' returns a beeswarm plot
#' @param ..., additional graphical parameters to be passed to \link{ggplot2::labs}
#'
#' @return Returns a violin plot or a beeswarm plot
#'
#' @note Pairs are grouped into 4 classes: None, 2 x single hit, double hit pairs. See \link{screen_heterotypic_tf} for more details
#'
#' @author Federico Comoglio
#'
#' @keywords graphics
#'
#' @export plot_coop_by_heterotypic_motif
#'
#'
plot_coop_by_heterotypic_motif <- function(tib_comb, tf1_id, tf2_id, type = 'violin', ...) {

  # validate args
  if(!type %in% c('violin', 'beeswarm'))
    stop('Plot type should be one of violin, beeswarm')

  # generate colnames prefix to match (ensures only the tf id is matched)
  # e.g. CTCF but not CTCFL
  tf1_id_prefix <- paste0(tf1_id, '_')
  tf2_id_prefix <- paste0(tf2_id, '_')

  # generate tf pair id
  pair_id       <- paste(tf1_id, '::', tf2_id)

  # select tf cols and define 4 classes:
  #  null: no tf1, tf2 motif hits
  #  tf1:  tf1 motif hit only (at either element)
  #  tf2:  tf2 motif hit only (at either element)
  #  tf12: tf1 motif within one element AND tf2 motif within the other element
  tib_plt <- tib_comb %>%
    select(starts_with(tf1_id_prefix), starts_with(tf2_id_prefix), coop_add) %>%
    mutate_at(1:4, as.logical) %>%
    mutate(null = (.[[1]] + .[[2]] + .[[3]] + .[[4]]) == 0,
           tf1  = (.[[1]] | .[[2]]) & !(.[[3]] | .[[4]]),
           tf2  = (.[[3]] | .[[4]]) & !(.[[1]] | .[[2]]),
           both = (.[[1]] & .[[4]]) | (.[[2]] & .[[3]])) %>%
    select(null, tf1, tf2, both, coop_add) %>%
    rename(null = 'None', tf1 = tf1_id, tf2 = tf2_id, both = pair_id) %>%
    # tall format
    gather(key = class, value = hit, ... = -coop_add) %>%
    filter(hit == TRUE) %>%
    mutate(class = factor(class, levels = c('None', tf1_id, tf2_id, pair_id))) %>%
    select(-hit)

  # plot
  if(type == 'violin') {

    p <- tib_plt %>%
      ggplot(aes(x = class, y = coop_add)) +
      geom_violin(aes(fill = class)) +
      geom_boxplot(width = 0.1)

  }
  else {

    p <- tib_plt %>%
      ggplot(aes(x = class, y = coop_add)) +
      geom_boxplot(width = 0.3) +
      ggbeeswarm::geom_beeswarm(aes(color = class), alpha = 0.5)

  }


  p +
    # color palette
    scale_fill_manual(values = c('gray50', 'skyblue3', 'skyblue3', 'orangered')) +
    # significance and labels
    ggsignif::geom_signif(comparisons      = list(c(2, 4), c(3, 4)),
                          test             = 'wilcox.test',
                          map_signif_level = FALSE,
                          step_increase    = 0.1) +
    labs(x = 'Configuration', y = 'Cooperativity', ...) +
    theme_bw() +
    theme(legend.position = 'none')
}
