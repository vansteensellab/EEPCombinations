

#' Summarize combinations represented in iPCR library
#'
#' @usage summarize_combinations(tib)
#'
#' @param tib tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#'
#' @return a tibble with the number of iPCR barcodes, total number of reads, mean and sd of read counts for each combination
#'
#' @note Homotypic combinations (possible basal library contamination) are excluded from computations. The output is sorted by decreasing number of barcodes
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export summarize_combinations
#'
#'
summarize_combinations <- function(tib) {

  tib %>%
    filter(with_basal == FALSE) %>%
    group_by(id) %>%
    summarise(n_bc      = n_distinct(barcode),
              n_reads   = sum(ipcr_counts),
              mu_counts = mean(ipcr_counts),
              sd_counts = sd(ipcr_counts)) %>%
    arrange(desc(n_bc))

}


#' @title Count the total number of fragments and orientations represented in the basal library
#'
#' @usage count_fragments(tib)
#'
#' @param tib tibble, containing basal library fragments (imported with \link{read_ipcr})
#'
#' @return called for its effects, returns a kable
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export count_fragments
#'
#'
count_fragments <- function(tib) {
  tib %>%
    distinct(frag1, id) %>%
    summarise(n_frag = n_distinct(frag1),
              n_frag_dir = n_distinct(id)) %>%
    kable(col.names = c('# Fragments', '# Orientations'), caption = 'Number of distinct fragments')
}


#' @title Count the total number of regulatory elements (E and P) and orientations represented in the basal library
#'
#' @usage count_elements(tib)
#'
#' @param tib tibble, containing basal library fragments (imported with \link{read_ipcr})
#'
#' @return called for its effects, returns a kable
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export count_elements
#'
#'
count_elements <- function(tib) {
  tib %>%
    mutate(type = substr(frag1, 1, 1)) %>%
    distinct(frag1, strand1, type) %>%
    group_by(type) %>%
    summarise(n_frag = n_distinct(frag1),
              n_dir = n()) %>%
    kable(caption = 'Number of distinct elements')
}


#' @title Count the total number of barcodes and reads for each element in the basal library
#'
#' @usage count_bc_reads(tib)
#'
#' @param tib tibble, containing basal library fragments (imported with \link{read_ipcr})
#'
#' @return called for its effects, returns a kable with summary statistics
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export count_bc_reads
#'
#'
count_bc_reads <- function(tib) {

  tib %>%
    mutate(type = substr(frag1, 1, 1)) %>%
    group_by(type) %>%
    summarise(n_bc = n_distinct(barcode),
              n_reads = sum(ipcr_counts)) %>%
    ungroup %>%
    mutate(perc_bc    = signif(n_bc / sum(n_bc) * 100, 3),
           perc_reads = signif(n_reads / sum(n_reads) * 100, 3)) %>%
    kable(caption = 'Number of barcodes and reads per element type',
          col.names = c('Type', '#BC', '#Reads', '%BC', '%Reads'))
}


#' @title Count the total number of combinations in the combinatorial library for each class of pairs
#'
#' @description Count the total number of combinations in the combinatorial library for each class of pairs, with and without accounting for orientation
#'
#' @usage count_combination_type(tib)
#'
#' @param tib tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#'
#' @return called for its effects, returns a kable
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export count_combination_type
#'
#'
count_combination_type <- function(tib) {

  # compute number of E and P represented in combinatorial library
  # with and without accounting for orientation
  tib <- tib %>%
    mutate(type = paste0(substr(frag1, 1, 1), ':', substr(frag2, 1, 1)))

  # compute number of fragments for each combination class
  tib_frag <- tib %>%
    distinct(frag1, strand1, frag2, strand2, type) %>%
    group_by(type) %>%
    summarise(n_frag = n_distinct(frag1, frag2),
              n_dir = n())

  # compute number of barcodes and reads for each combination class
  tib_bc <- tib %>%
    group_by(type) %>%
    summarise(n_bc = n_distinct(barcode),
              n_reads = sum(ipcr_counts))

  tib_out <- inner_join(tib_frag, tib_bc, by = 'type')


  tib_out %>%
    kable(caption = 'Number of combinations of each type', col.names = c('Type', '#Fragments', '#Directions', '#Barcodes', '#Reads')) %>%
    print

  return(tib_out)
}


#' @title Convert a combinatorial library tibble to matrix for heatmap representation
#'
#' @usage tib_to_mat(tib, var)
#'
#' @param tib tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#' @param var character, the column in tib that contains the values of interest
#'
#' @return a matrix suitable for heatmap representation
#' @note NAs in the input tib are replaced by 0 in the output matrix
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export tib_to_mat
#'
#'
tib_to_mat <- function(tib, var) {
  mat <- acast(tib, id2 ~ id1, value.var = var, fill = 0) %>%
    as.matrix
  return(mat)
}


#' @title Count the number of combinations in the combinatorial library
#'
#' @description Count the number of combinations in the combinatorial library, and relate it to the theoretical upperbound estimated from the fragment representation in the basal library. The fraction of homotypic pairs in the combinatorial library is also computed, providing an upperbound of the fraction of basal library contamination
#'
#' @usage count_combinations(tib_comb, tib_basal)
#'
#' @param tib_comb tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#' @param tib_basal tibble, containing basal library fragments (imported with \link{read_ipcr})
#'
#' @return called for its effects, returns a table
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export count_combinations
#'
#'
count_combinations <- function(tib_comb, tib_basal) {

  # compute number of fragment successfully cloned in basal library
  n_basal <- tib_basal %>%
    select(frag1) %>%
    n_distinct()

  # compute total number of combinations (homo + heterotypic)
  n_comb <- tib_comb %>%
    select(id) %>%
    unique %>%
    nrow

  # compute theoretical upperbound
  n_theor <- 4 * n_basal ^ 2

  # compute fraction of pairs that is likely contamination by basal library singlets
  # theoretical upperbound
  tib_contam <- tib_comb %>%
    filter(frag1 == frag2 & strand1 == strand2) %>%
    summarize(n_bc = n_distinct(barcode),
              n_reads = sum(ipcr_counts))

  # compute total number of barcodes and reads
  tib_total <- tib_comb %>%
    summarize(n_bc = n_distinct(barcode),
              n_reads = sum(ipcr_counts))

  tibble('n_comb'                = n_comb,
         'n_basal'               = n_basal,
         'theor_ub'              = n_theor,
         'repr_perc'             = signif(100 * n_comb / n_theor, 2),
         'singlet_ub_bc'         = tib_contam$n_bc,
         'singlet_ub_bc_perc'    = signif(100 * tib_contam$n_bc / tib_total$n_bc, 3),
         'singlet_ub_reads'      = tib_contam$n_reads,
         'singlet_ub_reads_perc' = signif(100 * tib_contam$n_reads / tib_total$n_reads, 3)) %>%
    pander(split.table = 80, style = 'rmarkdown', col.names = c('# Combinations', '# Basal (B)', 'Theor. UB (4*B^2)', 'Representation (%)',
                                                                'Singlet contam: # barcodes (UB)', 'Singlet contam: % barcodes (UB)',
                                                                'Singlet contam: # reads (UB)', 'Singlet contam: % reads (UB)'))
}



#' @title Filter out barcodes associated with heterotypic fragments from the basal library
#'
#' @usage mark_basal(tib)
#'
#' @param tib tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#'
#' @return a tibble, where a flag column (with_basal, logical) marks homotypic fragments (likely contamination by basal library elements)
#'
#' @note Homotypic fragments exhibit same element identity and orientation
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export mark_basal
#'
#'
mark_basal <- function(tib) {

  # mark putative basal library singlets
  # note: not distinguishable from homotypic duplets in same orientation
  tib %>%
    mutate(with_basal = (frag1 == frag2 & strand1 == strand2))
}


#' Filter out barcodes associated with heterotypic fragments from the basal library
#'
#' @usage remove_heterotypic(tib)
#'
#' @param tib tibble, containing basal library fragments (imported with \link{read_ipcr})
#'
#' @return a tibble (same format as input), with homotypic fragments only.
#'
#' @note Heterotypic fragments differ in element identity or orientation.
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export remove_heterotypic
#'
#'
remove_heterotypic <- function(tib) {

  n_het <- tib %>%
    filter(frag1 != frag2 | strand1 != strand2) %>%
    select(ipcr_counts) %>%
    sum

  n_tot <- tib %>%
    select(ipcr_counts) %>%
    sum

  message('Heterotypic: ', signif(n_het / n_tot * 100, 3), '%; ', n_het, ' / ', n_tot, ' reads')

  tib %>%
    filter(frag1 == frag2 & strand1 == strand2)
}


#' Extract most represented combinations in the combinatorial library
#'
#' @usage get_most_represented(tib, prom_only = FALSE)
#'
#' @param tib tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#' @param prom_only logical, if TRUE, restrict the analysis to promoters only. Default to FALSE
#'
#' @return called for its effects, returns a kable
#'
#' @note None.
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export get_most_represented
#'
#'
get_most_represented <- function(tib, prom_only = FALSE) {

  tib_comb1 <- tib %>%
    group_by(frag1, strand1) %>%
    summarise(n = n_distinct(frag2)) %>%
    rename(frag = frag1, strand = strand1)

  tib_comb2 <- tib %>%
    group_by(frag2, strand2) %>%
    summarise(n = n_distinct(frag1)) %>%
    rename(frag = frag2, strand = strand2)

  tib_top <- full_join(tib_comb1, tib_comb2, by = c('frag', 'strand')) %>%
    rename(n_comb_pos1 = n.x, n_comb_pos2 = n.y) %>%
    mutate(n_comb      = n_comb_pos1 + n_comb_pos2)

  if(prom_only) {
    tib_top <- tib_top %>%
      filter(substr(frag, 1, 1) == 'P')
  }

  tib_top %>%
    arrange(desc(n_comb)) %>%
    ungroup %>%
    dplyr::slice(1:10) %>%
    kable(caption   = 'Top hits',
          col.names = c('Fragment ID', 'Strand', '# Combinations (1st)', '# Combinations (2nd)', '# Combinations (all)'))
}


#' @title Filter out ambiguous barcode
#'
#' @usage remove_ambiguous(tib_basal, tib_comb)
#'
#' @param tib_basal tibble, containing basal library fragments (imported with \link{read_ipcr})
#' @param tib_comb tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#'
#' @return A list of tibbles, with filtered basal and combinatorial libraries
#'
#' @note Ambiguous barcodes are identified in both basal and combinatorial libraries
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export remove_ambiguous
#'
#'
remove_ambiguous <- function(tib_basal, tib_comb) {

  # identify identical barcodes in basal and combinatorial libraries
  tib_ambig <- inner_join(tib_basal, tib_comb, by = 'barcode')

  message('Ambiguous barcodes: ', nrow(tib_ambig), '; Removed.')

  # remove ambiguous barcodes from input tibbles
  tib_basal <- tib_basal %>%
    dplyr::slice(which(!tib_basal$barcode %in% tib_ambig$barcode))
  tib_comb <- tib_comb %>%
    dplyr::slice(which(!tib_comb$barcode %in% tib_ambig$barcode))

  return(list(tib_basal = tib_basal,
              tib_comb  = tib_comb))
}


#' @title Print a summary of total barcode counts
#'
#' @usage get_barcode_summary(tib_basal, tib_comb, tib_basal_merged, tib_comb_merged)
#'
#' @param tib_basal tibble, containing basal library fragments (imported with \link{read_ipcr})
#' @param tib_comb tibble, containing combinatorial library fragments (imported with \link{read_ipcr})
#' @param tib_basal_merged tibble, containing copy number and expression counts for barcodes with pDNA > 0 in the basal library (see \link{merge_ipcr_ecn})
#' @param tib_comb_merged tibble, containing copy number and expression counts for barcodes with pDNA > 0 in the basal library (see \link{merge_ipcr_ecn})
#'
#' @return called for its effects, returns a kable
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export get_barcode_summary
#'
#'
get_barcode_summary <- function(tib_basal, tib_comb, tib_basal_merged, tib_comb_merged) {

  n_basal    <- nrow(tib_basal)
  n_basal_mg <- nrow(tib_basal_merged)

  n_comb     <- nrow(tib_comb)
  n_comb_mg  <- nrow(tib_comb_merged)

  loss_basal <- (n_basal - n_basal_mg) / n_basal * 100
  loss_comb  <- (n_comb - n_comb_mg) / n_comb * 100

  df <- data.frame(n_basal,
                   n_basal_mg,
                   n_comb,
                   n_comb_mg,
                   signif(loss_basal, 3),
                   signif(loss_comb, 3))

  df %>%
    kable(caption = 'Summary of total barcode counts',
          col.names = c('Basal (iPCR)', 'Basal (pDNA > 0)', 'Comb (iPCR)', 'Comb (pDNA > 0)', 'Basal loss (%)', 'Comb loss (%)'))
}


#' @title Convert fragment coordinates in basal/combinatorial tibble to GRanges object
#'
#' @usage tib_to_gr(tib)
#'
#' @param tib tibble, containing basal or combinatorial library fragments (post-summarization with \link{add_metadata})
#'
#' @return A GRanges object (if input is basal library) or a GRangesList object (if input is combinatorial library)
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export tib_to_gr
#'
#'
tib_to_gr <- function(tib) {

  # check whether tib is basal or combinatorial library
  if(all(c('frag1', 'frag2') %in% names(tib))) {

    # combinatorial
    gr_frag1 <- GRanges(tib[['seqnames1']],
                        IRanges(tib[['start1']], tib[['end1']]), id = tib[['id']])
    gr_frag2 <- GRanges(tib[['seqnames2']],
                        IRanges(tib[['start2']], tib[['end2']]), id = tib[['id']])
    gr <- GRangesList('frag1' = gr_frag1, 'frag2' = gr_frag2)

  }

  else {

    # basal
    gr <- GRanges(tib[['seqnames']],
                  IRanges(tib[['start']], tib[['end']]), id = tib[['id']])

  }

  gr
}


#' @title Add TF motif scores to elements of a pair
#'
#' @usage add_motif_score(tib, tib_pwm)
#'
#' @param tib tibble, containing combinatorial library fragments (post-summarization with \link{add_metadata})
#' @param tib_pwm tibble, containing a fragment identifier and parsed FIMO scores (as returned by \link{})
#'
#' @return A tibble with two new columns for each motif column of tib_pwm
#'
#' @note The new columns suffixes _frag1 and _frag2 refer to the first and second element of the pair, respectively
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export add_motif_score
#'
#'
add_motif_score <- function(tib, tib_pwm) {

  tib <- tib %>%
    # annotate frag1
    left_join(tib_pwm, by = c('frag1' = 'id')) %>%
    # annotate frag2
    left_join(tib_pwm, by = c('frag2' = 'id'), suffix = c('_frag1', '_frag2'))

  tib
}


#' @title Load a Homer peak file (in BED format) and convert it to a GRanges object
#'
#' @usage homer_bed_to_gr(fn)
#'
#' @param fn character, the Homer BED filename containing the peaks of interest (including the full path)
#'
#' @return A GRanges object
#'
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export homer_bed_to_gr
#'
#'
homer_bed_to_gr <- function(fn) {

  # read in peak file
  df_peaks <- read.delim(fn, comment.char = '#', header = FALSE)

  # look for track header --> if detected, remove it
  track_header <- str_detect(df_peaks[1, 1], pattern = 'track')

  if(track_header) {
    df_peaks <- df_peaks[-1, ]
  }

  # coerce to granges object
  df_peaks %>%
    dplyr::select(V1:V3) %>%
    rename(V1 = 'seqnames', V2 = 'start', V3 = 'end') %>%
    as('GRanges') %>%
    sort

}


#' @title Add ChIP-seq peak overlap information to elements of a pair
#'
#' @usage add_chip_peak_overlap(tib, grl)
#'
#' @param tib tibble, containing combinatorial library fragments (post-summarization with \link{add_metadata})
#' @param grl GRangesList, where each element corresponds to a peak set
#'
#' @return A tibble with two new columns for each peak set in grl
#'
#' @note The new columns suffixes _frag1 and _frag2 refer to the first and second element of the pair, respectively
#'
#' @author Federico Comoglio
#'
#' @keywords utils
#'
#' @export add_chip_peak_overlap
#'
#'
add_chip_peak_overlap <- function(tib, grl) {

  # count peak sets
  n_ps <- length(grl)

  # extract genomic coordinates element 1
  tib_first <- tib_comb %>%
    dplyr::select(seqnames = seqnames1, start = start1, end = end1) %>%
    as('GRanges')

  # extract genomic coordinates element 2
  tib_second <- tib_comb %>%
    dplyr::select(seqnames = seqnames2, start = start2, end = end2) %>%
    as('GRanges')

  # olap with peaks in grl
  l_olap_first <- l_olap_second <- list()

  for(i in seq_len(n_ps)) {

    l_olap_first[[i]]  <- countOverlaps(tib_first, grl[[i]])
    l_olap_second[[i]] <- countOverlaps(tib_second, grl[[i]])

  }

  # coerce to tibbles --> binarize
  tib_olap_first  <- do.call(cbind, l_olap_first) %>%
    as_data_frame %>%
    mutate_all(funs(ifelse(. > 0, 1, 0)))

  tib_olap_second <- do.call(cbind, l_olap_second) %>%
    as_data_frame %>%
    mutate_all(funs(ifelse(. > 0, 1, 0)))

  # set colnames to TF, with suffix
  names(tib_olap_first)  <- paste0(names(grl), '_frag1')
  names(tib_olap_second) <- paste0(names(grl), '_frag2')

  # append cols to input tib
  tib %>%
    bind_cols(tib_olap_first, tib_olap_second)

}
