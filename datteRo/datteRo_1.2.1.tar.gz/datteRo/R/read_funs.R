

#' Read iPCR data table as returned by the epsure snakemake pipeline (*_unique_barcodes_frag_id_merged.tsv)
#'
#' @usage read_ipcr(fn, delim = '\t')
#'
#' @param fn character, the file name. This must include the full path (alternatively, use the here library)
#' @param delim character, the field separator. Default to '\t' (tab)
#'
#' @return a tibble with stripped element names (i.e. the prefix of the DAT library name is removed for convenience) and unique identifiers
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export read_ipcr
#'
#'
read_ipcr <- function(fn, delim = '\t') {

  # set column names
  col_names <- c('barcode', 'frag1', 'strand1', 'frag2', 'strand2', 'ipcr_counts', 'cluster_id')

  # read ipcr data as tibble
  tib <- readr::read_delim(fn, delim = delim, col_names = col_names)

  # strip DAT library name
  # pad fragment id with 0's
  # add unique fragment identifier
  tib %>%
    mutate(prefix1 = str_sub(frag1, 1, 1),
           frag1 = str_remove(frag1, '_.*'),
           frag1 = str_remove(frag1, '[EP]'),
           frag1 = str_pad(frag1, width = 3, pad = '0'),
           frag1 = paste0(prefix1, frag1),
           prefix2 = str_sub(frag2, 1, 1),
           frag2 = str_remove(frag2, '_.*'),
           frag2 = str_remove(frag2, '[EP]'),
           frag2 = str_pad(frag2, width = 3, pad = '0'),
           frag2 = paste0(prefix2, frag2),
           id = paste0(frag1, strand1, frag2, strand2))
}


#' Read expression (cDNA)/copy number (pDNA) data tables as returned by the epsure snakemake pipeline (*_barcode_counts.tsv)
#'
#' @usage read_ecn(fn, delim = '\t')
#'
#' @param fn character, the file name. This must include the full path (alternatively, use the here library)
#' @param delim character, the field separator. Default to '\t' (tab)
#' @param col_lab character, the sample label
#'
#' @return a tibble (2 columns: barcode, counts). The second column (counts) is named according to col_lab.
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export read_ecn
#'
#'
read_ecn <- function(fn, delim = '\t', col_lab) {

  # check whether col_lab missing
  if(missing(col_lab))
    stop('Argument col_lab missing. This should contain the sample-specific info (e.g. cdna_counts_1)')

  # set column names
  # note: col1 == col3
  col_names <- c('barcode', col_lab, 'dupl')

  # read ecn data as tibble
  tib <- readr::read_delim(fn, delim = delim, col_names = col_names) %>%
    select(-dupl)

  tib
}


#' Read DAT design (BED format)
#'
#' @usage read_dat_design(fn)
#'
#' @param fn character, the file name. This must include the full path (alternatively, use the here library)
#'
#' @return a tibble
#' @note None
#'
#' @author Federico Comoglio
#'
#' @keywords core
#'
#' @export read_dat_design
#'
#'
read_dat_design <- function(fn) {

  read_tsv(fn, skip = 1, col_names = c('seqnames', 'start', 'end', 'frag', 'score', 'color')) %>%
    dplyr::select(frag, seqnames, start, end) %>%
    mutate(prefix = str_sub(frag, 1, 1),
           frag = str_remove(frag, '_.*'),
           frag = str_remove(frag, '[EP]'),
           frag = str_pad(frag, width = 3, pad = '0'),
           frag = paste0(prefix, frag)) %>%
    dplyr::select(-prefix)

}
