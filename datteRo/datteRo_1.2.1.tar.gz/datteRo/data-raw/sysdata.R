# chromosome sizes for mm10 genome

df                  <- read.table('/home/f.comoglio/mydata/Annotations/mm10_gencode_v_m16.chrom.sizes')[1:21, ]
gr_chrom_sizes_mm10 <- GRanges(df[['V1']], IRanges(1, df[['V2']]))

# added to R/sysdata.rda using
# devtools::use_data(gr_chrom_sizes_mm10, internal = TRUE)
# see http://r-pkgs.had.co.nz/data.html
