# datteRo

An R package for the analysis of DAT (Deconstruct A TAD) experiments. Currently intended for internal use. The name means 'date' (the fruit) in Italian, and could perhaps be understood as ‘Deconstruct A TAD and Then Extract Relevant Observations’
